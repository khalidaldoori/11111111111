import React from 'react';
import { NavLink } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Home, Map, Calendar, Users, BarChart2, Settings as SettingsIcon, LogOut, X, Briefcase, UserCheck, Package, MapPin, BedDouble, Plane, Ship, Train, ConciergeBell, ShieldCheck, CreditCard, Briefcase as BriefcaseBusiness, Headphones as Headset, BookOpen, Building, UserPlus, FileText, Clock, Award, CalendarDays, KanbanSquare, Archive, Globe, Hotel as City, MountainSnow, HelpCircle, Hotel, Bed, Car, Bus, Anchor, Store as Station } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

const navItems = [
  { path: '/', label: 'لوحة التحكم', icon: <Home className="h-5 w-5" />, exact: true },
  { 
    label: 'إدارة العملاء', 
    icon: <Users className="h-5 w-5" />,
    subItems: [
      { path: '/customers/persons', label: 'الأشخاص', icon: <UserPlus className="h-4 w-4" /> },
      { path: '/customers/companies', label: 'الشركات', icon: <Building className="h-4 w-4" /> },
      { path: '/customers/company-visits', label: 'زيارات الشركات', icon: <CalendarDays className="h-4 w-4" /> },
      { path: '/customers/visit-statuses', label: 'حالات الزيارات', icon: <FileText className="h-4 w-4" /> },
      { path: '/customers/communication-log', label: 'سجل التواصل', icon: <Headset className="h-4 w-4" /> },
    ]
  },
  { 
    label: 'إدارة الموظفين', 
    icon: <UserCheck className="h-5 w-5" />,
    subItems: [
      { path: '/employees/data', label: 'بيانات الموظفين', icon: <Users className="h-4 w-4" /> },
      { path: '/employees/roles', label: 'الأدوار والصلاحيات', icon: <ShieldCheck className="h-4 w-4" /> },
      { path: '/employees/performance', label: 'تقييم الأداء', icon: <BarChart2 className="h-4 w-4" /> },
      { path: '/employees/incentives', label: 'الحوافز والمكافآت', icon: <Award className="h-4 w-4" /> },
      { path: '/employees/tasks', label: 'جدولة المهام', icon: <Clock className="h-4 w-4" /> },
    ]
  },
  { 
    label: 'العروض والباقات', 
    icon: <Package className="h-5 w-5" />,
    subItems: [
      { path: '/packages/ready-offers', label: 'العروض الجاهزة', icon: <Package className="h-4 w-4" /> },
      { path: '/packages/custom-packages', label: 'الباقات المخصصة', icon: <Package className="h-4 w-4" /> },
      { path: '/packages/booking-formats', label: 'تنسيقات الحجز', icon: <FileText className="h-4 w-4" /> },
      { path: '/packages/kanban', label: 'لوحة كانبان', icon: <KanbanSquare className="h-4 w-4" /> },
      { path: '/packages/archive', label: 'أرشيف العروض', icon: <Archive className="h-4 w-4" /> },
    ]
  },
  { path: '/bookings', label: 'الحجوزات', icon: <Calendar className="h-5 w-5" /> },
  { 
    label: 'إدارة الوجهات', 
    icon: <MapPin className="h-5 w-5" />,
    subItems: [
      { path: '/destinations/countries', label: 'الدول', icon: <Globe className="h-4 w-4" /> },
      { path: '/destinations/cities', label: 'المدن', icon: <City className="h-4 w-4" /> },
      { path: '/destinations/attractions', label: 'المعالم السياحية', icon: <MountainSnow className="h-4 w-4" /> },
    ]
  },
  { 
    label: 'إدارة الإقامة', 
    icon: <BedDouble className="h-5 w-5" />,
    subItems: [
      { path: '/accommodation/hotels', label: 'الفنادق', icon: <Hotel className="h-4 w-4" /> },
      { path: '/accommodation/room-types', label: 'أنواع الغرف', icon: <Bed className="h-4 w-4" /> },
      { path: '/accommodation/apartments', label: 'الشقق الفندقية', icon: <Building className="h-4 w-4" /> },
      { path: '/accommodation/resorts', label: 'المنتجعات', icon: <MapPin className="h-4 w-4" /> },
    ]
  },
  { 
    label: 'إدارة النقل', 
    icon: <Plane className="h-5 w-5" />,
    subItems: [
      { path: '/transportation/flights', label: 'الطيران', icon: <Plane className="h-4 w-4" /> },
      { path: '/transportation/ground', label: 'النقل البري', icon: <Car className="h-4 w-4" /> },
      { path: '/transportation/sea', label: 'الرحلات البحرية', icon: <Ship className="h-4 w-4" /> },
      { path: '/transportation/trains', label: 'القطارات', icon: <Train className="h-4 w-4" /> },
    ]
  },
  { 
    label: 'الخدمات الإضافية', 
    icon: <ConciergeBell className="h-5 w-5" />,
    subItems: [
      { path: '/services/guides', label: 'المرشدين السياحيين', icon: <Users className="h-4 w-4" /> },
      { path: '/services/tours', label: 'الجولات السياحية', icon: <Map className="h-4 w-4" /> },
      { path: '/services/vip', label: 'خدمات VIP', icon: <Award className="h-4 w-4" /> },
      { path: '/services/insurance', label: 'التأمين السياحي', icon: <ShieldCheck className="h-4 w-4" /> },
    ]
  },
  { 
    label: 'إدارة التأشيرات', 
    icon: <ShieldCheck className="h-5 w-5" />,
    subItems: [
      { path: '/visas/requirements', label: 'متطلبات التأشيرات', icon: <FileText className="h-4 w-4" /> },
      { path: '/visas/requests', label: 'طلبات التأشيرات', icon: <Briefcase className="h-4 w-4" /> },
    ]
  },
  { 
    label: 'النظام المالي', 
    icon: <CreditCard className="h-5 w-5" />,
    subItems: [
      { path: '/financial/invoices', label: 'الفواتير والمدفوعات', icon: <FileText className="h-4 w-4" /> },
      { path: '/financial/expenses', label: 'المصروفات', icon: <CreditCard className="h-4 w-4" /> },
    ]
  },
  { 
    label: 'العمليات', 
    icon: <BriefcaseBusiness className="h-5 w-5" />,
    subItems: [
      { path: '/operations/scheduling', label: 'جدولة العمليات', icon: <Clock className="h-4 w-4" /> },
      { path: '/operations/workflow', label: 'متابعة سير العمل', icon: <KanbanSquare className="h-4 w-4" /> },
    ]
  },
  { 
    label: 'رعاية العملاء', 
    icon: <Headset className="h-5 w-5" />,
    subItems: [
      { path: '/customer-care/inquiries', label: 'الاستفسارات', icon: <Users className="h-4 w-4" /> },
      { path: '/customer-care/complaints', label: 'الشكاوى', icon: <FileText className="h-4 w-4" /> },
    ]
  },
  { path: '/reports', label: 'التقارير', icon: <BarChart2 className="h-5 w-5" /> },
  { path: '/settings', label: 'الإعدادات', icon: <SettingsIcon className="h-5 w-5" /> },
  { 
    label: 'دليل النظام', 
    icon: <BookOpen className="h-5 w-5" />,
    subItems: [
      { path: '/system-guide/user-manual', label: 'دليل المستخدم', icon: <BookOpen className="h-4 w-4" /> },
      { path: '/system-guide/faq', label: 'الأسئلة الشائعة', icon: <HelpCircle className="h-4 w-4" /> },
    ]
  },
];


const NavItemContent = ({ item, isActive }) => (
  <>
    <motion.div
      initial={{ scale: 1 }}
      whileHover={{ scale: 1.1 }}
      className="ml-3" 
    >
      {item.icon}
    </motion.div>
    <span className="flex-1">{item.label}</span>
    {isActive && !item.subItems && (
      <motion.div
        layoutId="sidebar-indicator"
        className="w-1.5 h-6 bg-white rounded-full mr-2" 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.2 }}
      />
    )}
  </>
);

const Sidebar = ({ onLogout, closeSidebar }) => {
  const [openAccordion, setOpenAccordion] = React.useState(null);

  return (
    <div className="flex flex-col h-full">
      {closeSidebar && (
        <div className="lg:hidden absolute left-0 p-2 z-50">
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={closeSidebar}
            className="text-white hover:bg-blue-700"
          >
            <X className="h-6 w-6" />
          </Button>
        </div>
      )}

      <div className="flex items-center justify-center h-16 flex-shrink-0 px-4 bg-blue-900">
        <motion.h1 
          initial={{ scale: 0.9 }}
          animate={{ scale: 1 }}
          className="text-xl font-bold text-white"
        >
          شركة السياحة
        </motion.h1>
      </div>

      <nav className="mt-5 flex-1 px-2 space-y-1 overflow-y-auto">
        <Accordion type="single" collapsible value={openAccordion} onValueChange={setOpenAccordion}>
          {navItems.map((item, index) => (
            item.subItems ? (
              <AccordionItem value={`item-${index}`} key={item.label} className="border-none">
                <AccordionTrigger 
                  className="w-full text-blue-100 hover:bg-blue-800 hover:no-underline px-2 py-2 text-sm font-medium rounded-md transition-all duration-200 flex items-center justify-between"
                >
                  <div className="flex items-center">
                    <NavItemContent item={item} isActive={false} />
                  </div>
                </AccordionTrigger>
                <AccordionContent className="pb-1">
                  <div className="pr-4 space-y-1 mt-1">
                  {item.subItems.map(subItem => (
                    <NavLink
                      key={subItem.path}
                      to={subItem.path}
                      onClick={closeSidebar}
                      className={({ isActive }) => 
                        `${isActive 
                          ? 'bg-blue-600 text-white' 
                          : 'text-blue-200 hover:bg-blue-700 hover:text-white'
                        } group flex items-center px-2 py-2 text-xs font-medium rounded-md transition-all duration-200`
                      }
                    >
                      <NavItemContent item={subItem} isActive={false} />
                    </NavLink>
                  ))}
                  </div>
                </AccordionContent>
              </AccordionItem>
            ) : (
              <NavLink
                key={item.path}
                to={item.path}
                end={item.exact}
                onClick={closeSidebar}
                className={({ isActive }) => 
                  `${isActive 
                    ? 'bg-blue-700 text-white' 
                    : 'text-blue-100 hover:bg-blue-800'
                  } group flex items-center px-2 py-2 text-sm font-medium rounded-md transition-all duration-200`
                }
              >
                {({ isActive }) => <NavItemContent item={item} isActive={isActive} />}
              </NavLink>
            )
          ))}
        </Accordion>
      </nav>

      <div className="p-4 border-t border-blue-800">
        <Button
          variant="ghost"
          className="w-full justify-start text-blue-100 hover:bg-blue-800 hover:text-white"
          onClick={onLogout}
        >
          <LogOut className="h-5 w-5 ml-2" />
          تسجيل الخروج
        </Button>
      </div>
    </div>
  );
};

export default Sidebar;