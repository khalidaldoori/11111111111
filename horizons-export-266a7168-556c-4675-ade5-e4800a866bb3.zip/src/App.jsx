import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { motion } from 'framer-motion';

import DashboardLayout from '@/layouts/DashboardLayout';
import Login from '@/pages/Login';
import NotFound from '@/pages/NotFound';

import Dashboard from '@/pages/Dashboard';

import CustomersPersons from '@/pages/customers/Persons';
import CustomersCompanies from '@/pages/customers/Companies';
import CustomersCompanyVisits from '@/pages/customers/CompanyVisits';
import CustomersVisitStatuses from '@/pages/customers/VisitStatuses';
import CustomersCommunicationLog from '@/pages/customers/CommunicationLog';

import EmployeesData from '@/pages/employees/Data';
import EmployeesRoles from '@/pages/employees/Roles';
import EmployeesPerformance from '@/pages/employees/Performance';
import EmployeesIncentives from '@/pages/employees/Incentives';
import EmployeesTasks from '@/pages/employees/Tasks';

import PackagesReadyOffers from '@/pages/packages/ReadyOffers';
import PackagesCustomPackages from '@/pages/packages/CustomPackages';
import PackagesBookingFormats from '@/pages/packages/BookingFormats';
import PackagesKanban from '@/pages/packages/Kanban';
import PackagesArchive from '@/pages/packages/Archive';

import Bookings from '@/pages/Bookings';

import DestinationsCountries from '@/pages/destinations/Countries';
import DestinationsCities from '@/pages/destinations/Cities';
import DestinationsAttractions from '@/pages/destinations/Attractions';

import AccommodationHotels from '@/pages/accommodation/Hotels';
import AccommodationRoomTypes from '@/pages/accommodation/RoomTypes';
import AccommodationApartments from '@/pages/accommodation/Apartments';
import AccommodationResorts from '@/pages/accommodation/Resorts';

import TransportationFlights from '@/pages/transportation/Flights';
import TransportationGround from '@/pages/transportation/Ground';
import TransportationSea from '@/pages/transportation/Sea';
import TransportationTrains from '@/pages/transportation/Trains';

import ServicesGuides from '@/pages/services/Guides';
import ServicesTours from '@/pages/services/Tours';
import ServicesVip from '@/pages/services/Vip';
import ServicesInsurance from '@/pages/services/Insurance';

import VisasRequirements from '@/pages/visas/Requirements';
import VisasRequests from '@/pages/visas/Requests';

import FinancialInvoices from '@/pages/financial/Invoices';
import FinancialExpenses from '@/pages/financial/Expenses';

import OperationsScheduling from '@/pages/operations/Scheduling';
import OperationsWorkflow from '@/pages/operations/Workflow';

import CustomerCareInquiries from '@/pages/customer-care/Inquiries';
import CustomerCareComplaints from '@/pages/customer-care/Complaints';

import Reports from '@/pages/Reports';
import Settings from '@/pages/Settings';

import SystemGuideUserManual from '@/pages/system-guide/UserManual';
import SystemGuideFaq from '@/pages/system-guide/Faq';

const PlaceholderPage = ({ title }) => (
  <div className="p-6">
    <h1 className="text-2xl font-semibold text-primary">{title}</h1>
    <p className="mt-2 text-muted-foreground">هذه الصفحة قيد الإنشاء. سيتم إضافة المحتوى قريبًا!</p>
    <div className="mt-8">
      <img  alt="رسم توضيحي لموقع قيد الإنشاء" className="mx-auto w-1/2 max-w-sm" src="https://images.unsplash.com/photo-1585998190016-eba05b59e521" />
    </div>
  </div>
);


function App() {
  const [isLoggedIn, setIsLoggedIn] = React.useState(
    localStorage.getItem('isLoggedIn') === 'true'
  );

  const handleLogin = () => {
    localStorage.setItem('isLoggedIn', 'true');
    setIsLoggedIn(true);
  };

  const handleLogout = () => {
    localStorage.setItem('isLoggedIn', 'false');
    setIsLoggedIn(false);
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="min-h-screen bg-background"
    >
      <Routes>
        <Route 
          path="/login" 
          element={<Login onLogin={handleLogin} isLoggedIn={isLoggedIn} />} 
        />

        <Route element={<DashboardLayout onLogout={handleLogout} />}>
          <Route path="/" element={<Dashboard />} />
          
          {/* Customers */}
          <Route path="/customers" element={<Navigate to="/customers/persons" replace />} />
          <Route path="/customers/persons" element={<CustomersPersons />} />
          <Route path="/customers/companies" element={<CustomersCompanies />} />
          <Route path="/customers/company-visits" element={<CustomersCompanyVisits />} />
          <Route path="/customers/visit-statuses" element={<CustomersVisitStatuses />} />
          <Route path="/customers/communication-log" element={<CustomersCommunicationLog />} />

          {/* Employees */}
          <Route path="/employees" element={<Navigate to="/employees/data" replace />} />
          <Route path="/employees/data" element={<EmployeesData />} />
          <Route path="/employees/roles" element={<EmployeesRoles />} />
          <Route path="/employees/performance" element={<EmployeesPerformance />} />
          <Route path="/employees/incentives" element={<EmployeesIncentives />} />
          <Route path="/employees/tasks" element={<EmployeesTasks />} />

          {/* Packages */}
          <Route path="/packages" element={<Navigate to="/packages/ready-offers" replace />} />
          <Route path="/packages/ready-offers" element={<PackagesReadyOffers />} />
          <Route path="/packages/custom-packages" element={<PackagesCustomPackages />} />
          <Route path="/packages/booking-formats" element={<PackagesBookingFormats />} />
          <Route path="/packages/kanban" element={<PackagesKanban />} />
          <Route path="/packages/archive" element={<PackagesArchive />} />
          
          <Route path="/bookings" element={<Bookings />} />

          {/* Destinations */}
          <Route path="/destinations" element={<Navigate to="/destinations/countries" replace />} />
          <Route path="/destinations/countries" element={<DestinationsCountries />} />
          <Route path="/destinations/cities" element={<DestinationsCities />} />
          <Route path="/destinations/attractions" element={<DestinationsAttractions />} />

          {/* Accommodation */}
          <Route path="/accommodation" element={<Navigate to="/accommodation/hotels" replace />} />
          <Route path="/accommodation/hotels" element={<AccommodationHotels />} />
          <Route path="/accommodation/room-types" element={<AccommodationRoomTypes />} />
          <Route path="/accommodation/apartments" element={<AccommodationApartments />} />
          <Route path="/accommodation/resorts" element={<AccommodationResorts />} />
          
          {/* Transportation */}
          <Route path="/transportation" element={<Navigate to="/transportation/flights" replace />} />
          <Route path="/transportation/flights" element={<TransportationFlights />} />
          <Route path="/transportation/ground" element={<TransportationGround />} />
          <Route path="/transportation/sea" element={<TransportationSea />} />
          <Route path="/transportation/trains" element={<TransportationTrains />} />

          {/* Services */}
          <Route path="/services" element={<Navigate to="/services/guides" replace />} />
          <Route path="/services/guides" element={<ServicesGuides />} />
          <Route path="/services/tours" element={<ServicesTours />} />
          <Route path="/services/vip" element={<ServicesVip />} />
          <Route path="/services/insurance" element={<ServicesInsurance />} />
          
          {/* VISAs */}
          <Route path="/visas" element={<Navigate to="/visas/requirements" replace />} />
          <Route path="/visas/requirements" element={<VisasRequirements />} />
          <Route path="/visas/requests" element={<VisasRequests />} />
          
          {/* Financial */}
          <Route path="/financial" element={<Navigate to="/financial/invoices" replace />} />
          <Route path="/financial/invoices" element={<FinancialInvoices />} />
          <Route path="/financial/expenses" element={<FinancialExpenses />} />

          {/* Operations */}
          <Route path="/operations" element={<Navigate to="/operations/scheduling" replace />} />
          <Route path="/operations/scheduling" element={<OperationsScheduling />} />
          <Route path="/operations/workflow" element={<OperationsWorkflow />} />

          {/* Customer Care */}
          <Route path="/customer-care" element={<Navigate to="/customer-care/inquiries" replace />} />
          <Route path="/customer-care/inquiries" element={<CustomerCareInquiries />} />
          <Route path="/customer-care/complaints" element={<CustomerCareComplaints />} />

          <Route path="/reports" element={<Reports />} />
          <Route path="/settings" element={<Settings />} />

          {/* System Guide */}
          <Route path="/system-guide" element={<Navigate to="/system-guide/user-manual" replace />} />
          <Route path="/system-guide/user-manual" element={<SystemGuideUserManual />} />
          <Route path="/system-guide/faq" element={<SystemGuideFaq />} />
          
          {/* Legacy routes - remove or update as needed */}
          <Route path="/trips" element={<PlaceholderPage title="إدارة الرحلات (Legacy - سيتم دمجها)" />} />
        </Route>

        <Route path="*" element={<NotFound />} />
      </Routes>
    </motion.div>
  );
}

export default App;