import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, PieChart, TrendingUp, Users, FileText } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Reports = () => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <h1 className="text-3xl font-bold text-primary">التقارير والإحصائيات</h1>
        <Button className="bg-primary hover:bg-primary/90 text-primary-foreground btn-glow">
          <FileText className="ml-2 h-5 w-5" />
          تصدير جميع التقارير
        </Button>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        <motion.div initial={{ opacity: 0, y:10 }} animate={{ opacity: 1, y:0 }} transition={{ delay: 0.1 }}>
          <Card className="shadow-lg card-hover">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">إجمالي الإيرادات</CardTitle>
              <BarChart className="h-5 w-5 text-green-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground">150,780 ر.س</div>
              <p className="text-xs text-muted-foreground">+15.2% عن الشهر الماضي</p>
              <div className="h-32 mt-4 bg-green-100 rounded-md flex items-center justify-center">
                <TrendingUp className="h-16 w-16 text-green-500 opacity-50" />
                 <p className="text-sm text-green-700">رسم بياني للإيرادات هنا</p>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, y:10 }} animate={{ opacity: 1, y:0 }} transition={{ delay: 0.2 }}>
          <Card className="shadow-lg card-hover">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">الحجوزات حسب الوجهة</CardTitle>
              <PieChart className="h-5 w-5 text-blue-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground">5 وجهات رئيسية</div>
              <p className="text-xs text-muted-foreground">باريس هي الأكثر طلباً</p>
              <div className="h-32 mt-4 bg-blue-100 rounded-md flex items-center justify-center">
                <PieChart className="h-16 w-16 text-blue-500 opacity-50" />
                <p className="text-sm text-blue-700">رسم بياني دائري هنا</p>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, y:10 }} animate={{ opacity: 1, y:0 }} transition={{ delay: 0.3 }}>
          <Card className="shadow-lg card-hover">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">رضا العملاء</CardTitle>
              <Users className="h-5 w-5 text-purple-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground">92%</div>
              <p className="text-xs text-muted-foreground">بناءً على 500 تقييم</p>
              <div className="h-32 mt-4 bg-purple-100 rounded-md flex items-center justify-center">
                 <Users className="h-16 w-16 text-purple-500 opacity-50" />
                 <p className="text-sm text-purple-700">مؤشر رضا العملاء هنا</p>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      <Card className="shadow-lg card-hover">
        <CardHeader>
          <CardTitle className="text-xl text-primary">تقرير المبيعات المفصل</CardTitle>
          <CardDescription className="text-muted-foreground">نظرة عامة على أداء المبيعات خلال الفترة المحددة.</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">سيتم عرض جدول مفصل أو رسم بياني تفاعلي هنا لتحليل المبيعات.</p>
          <img  alt="رسم بياني يوضح نمو المبيعات عبر الزمن" className="w-full h-64 object-contain mt-4 rounded-md bg-gray-100" src="https://images.unsplash.com/photo-1643917853949-74f4eba1c89b" />
        </CardContent>
      </Card>

    </motion.div>
  );
};

export default Reports;