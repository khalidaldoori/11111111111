import React from 'react';
import { motion } from 'framer-motion';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { PlusCircle, Filter, Download, Mail, Phone, MessageSquare, User } from 'lucide-react';
import { Input } from '@/components/ui/input';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";

const sampleLogs = [
  { id: "CL001", customer: "عبدالله السالم", date: "2025-06-01", channel: "بريد إلكتروني", subject: "استفسار عن رحلة باريس", agent: "نورة" },
  { id: "CL002", customer: "شركة السياحة العالمية", date: "2025-06-03", channel: "مكالمة هاتفية", subject: "متابعة عرض الشراكة", agent: "أحمد" },
  { id: "CL003", customer: "نورة الحمد", date: "2025-06-05", channel: "رسالة نصية", subject: "تأكيد حجز الفندق", agent: "سارة" },
  { id: "CL004", customer: "خالد الغامدي", date: "2025-06-07", channel: "بريد إلكتروني", subject: "طلب تعديل حجز", agent: "نورة" },
];

const getChannelIcon = (channel) => {
  switch (channel) {
    case "بريد إلكتروني": return <Mail className="h-5 w-5 text-blue-500" />;
    case "مكالمة هاتفية": return <Phone className="h-5 w-5 text-green-500" />;
    case "رسالة نصية": return <MessageSquare className="h-5 w-5 text-purple-500" />;
    default: return <User className="h-5 w-5 text-gray-500" />;
  }
};

const CustomersCommunicationLog = () => {
  const [searchTerm, setSearchTerm] = React.useState('');

  const filteredLogs = sampleLogs.filter(log =>
    log.customer.toLowerCase().includes(searchTerm.toLowerCase()) ||
    log.subject.toLowerCase().includes(searchTerm.toLowerCase()) ||
    log.agent.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <h1 className="text-3xl font-bold text-primary">سجل التواصل مع العملاء</h1>
        <div className="flex gap-2">
          <Button variant="outline" className="btn-glow">
            <Filter className="ml-2 h-4 w-4" />
            تصفية
          </Button>
          <Button className="bg-primary hover:bg-primary/90 text-primary-foreground btn-glow">
            <PlusCircle className="ml-2 h-5 w-5" />
            إضافة سجل تواصل
          </Button>
        </div>
      </div>

      <Card className="shadow-lg">
        <CardHeader className="flex flex-col md:flex-row justify-between items-center gap-2">
          <CardTitle className="text-xl text-primary">قائمة سجلات التواصل</CardTitle>
           <div className="flex gap-2 w-full md:w-auto">
            <Input 
              type="text"
              placeholder="ابحث في السجلات..."
              className="w-full md:w-64 bg-background/80 border-border focus:ring-primary"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <Button variant="outline" size="icon" className="btn-glow">
              <Download className="h-5 w-5" />
              <span className="sr-only">تصدير</span>
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {filteredLogs.length === 0 ? (
             <p className="text-center text-muted-foreground py-8">لا توجد سجلات تطابق بحثك.</p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>المعرف</TableHead>
                    <TableHead>العميل/الشركة</TableHead>
                    <TableHead>التاريخ</TableHead>
                    <TableHead>القناة</TableHead>
                    <TableHead>الموضوع</TableHead>
                    <TableHead>الموظف المسؤول</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredLogs.map((log, index) => (
                    <motion.tr 
                      key={log.id}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ duration: 0.3, delay: index * 0.05 }}
                      className="hover:bg-muted/50 transition-colors"
                    >
                      <TableCell className="font-medium">{log.id}</TableCell>
                      <TableCell>{log.customer}</TableCell>
                      <TableCell>{log.date}</TableCell>
                      <TableCell className="flex items-center gap-2">
                        {getChannelIcon(log.channel)}
                        {log.channel}
                      </TableCell>
                      <TableCell>{log.subject}</TableCell>
                      <TableCell>
                        <Badge variant="secondary">{log.agent}</Badge>
                      </TableCell>
                    </motion.tr>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default CustomersCommunicationLog;