import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckCircle, XCircle, AlertTriangle, Clock, PlusCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';

const visitStatuses = [
  { name: "مجدولة", icon: <Clock className="h-8 w-8 text-blue-500" />, color: "bg-blue-100", description: "الزيارات التي تم تحديد موعد لها ولم تتم بعد." },
  { name: "مكتملة", icon: <CheckCircle className="h-8 w-8 text-green-500" />, color: "bg-green-100", description: "الزيارات التي تمت بنجاح." },
  { name: "مؤجلة", icon: <AlertTriangle className="h-8 w-8 text-yellow-500" />, color: "bg-yellow-100", description: "الزيارات التي تم تأجيلها لموعد لاحق." },
  { name: "ملغاة", icon: <XCircle className="h-8 w-8 text-red-500" />, color: "bg-red-100", description: "الزيارات التي تم إلغاؤها." },
];

const CustomersVisitStatuses = () => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <h1 className="text-3xl font-bold text-primary">حالات زيارات الشركات</h1>
        <Button className="bg-primary hover:bg-primary/90 text-primary-foreground btn-glow">
          <PlusCircle className="ml-2 h-5 w-5" />
          إضافة حالة جديدة
        </Button>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        {visitStatuses.map((status, index) => (
          <motion.div
            key={status.name}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3, delay: index * 0.1 }}
          >
            <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300 card-hover text-center glass-effect h-full">
              <CardHeader className="pb-2">
                <div className={`p-3 rounded-full ${status.color} inline-block mx-auto mb-3`}>
                  {status.icon}
                </div>
                <CardTitle className="text-xl font-semibold text-foreground">{status.name}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">{status.description}</p>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
      <div className="text-center mt-8">
        <img  alt="رسم توضيحي لسير عمل حالات الزيارة" className="mx-auto w-full max-w-2xl" src="https://images.unsplash.com/photo-1542744173-8e7e53415bb0" />
      </div>
    </motion.div>
  );
};

export default CustomersVisitStatuses;