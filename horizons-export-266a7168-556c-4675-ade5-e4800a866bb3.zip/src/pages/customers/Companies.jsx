import React from 'react';
import { motion } from 'framer-motion';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { PlusCircle, Edit2, Trash2, Search, Building, Link as LinkIcon, Users } from 'lucide-react';
import { Input } from '@/components/ui/input';

const sampleCompanies = [
  { id: 1, name: "شركة السياحة العالمية", industry: "السياحة والسفر", employees: 50, website: "globaltravel.com", logoSeed: "travel_company" },
  { id: 2, name: "مجموعة فنادق النخبة", industry: "الضيافة", employees: 200, website: "elitehotels.com", logoSeed: "hotel_group" },
  { id: 3, name: "خدمات النقل السريع", industry: "النقل واللوجستيات", employees: 120, website: "fastransit.com", logoSeed: "transport_service" },
];

const CustomersCompanies = () => {
  const [searchTerm, setSearchTerm] = React.useState('');

  const filteredCompanies = sampleCompanies.filter(company =>
    company.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    company.industry.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <h1 className="text-3xl font-bold text-primary">إدارة العملاء (الشركات)</h1>
        <Button className="bg-primary hover:bg-primary/90 text-primary-foreground btn-glow">
          <PlusCircle className="ml-2 h-5 w-5" />
          إضافة شركة جديدة
        </Button>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
        <Input 
          type="text"
          placeholder="ابحث عن شركة..."
          className="pl-10 w-full md:w-1/2 lg:w-1/3 bg-background/80 border-border focus:ring-primary"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

       {filteredCompanies.length === 0 && (
        <p className="text-center text-muted-foreground py-8">لا توجد شركات تطابق بحثك.</p>
      )}

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {filteredCompanies.map((company, index) => (
          <motion.div
            key={company.id}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3, delay: index * 0.05 }}
          >
            <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300 card-hover h-full flex flex-col">
              <CardHeader className="flex flex-row items-start space-x-4 rtl:space-x-reverse pb-3">
                <div className="p-3 bg-primary/10 rounded-md">
                   <Building className="h-8 w-8 text-primary" />
                </div>
                <div>
                  <CardTitle className="text-lg text-primary">{company.name}</CardTitle>
                  <p className="text-sm text-muted-foreground">{company.industry}</p>
                </div>
              </CardHeader>
              <CardContent className="space-y-2 text-sm flex-grow">
                <div className="flex items-center text-muted-foreground">
                  <Users className="h-4 w-4 ml-2 text-primary" />
                  <span>{company.employees} موظف</span>
                </div>
                <div className="flex items-center text-muted-foreground">
                  <LinkIcon className="h-4 w-4 ml-2 text-primary" />
                  <a href={`http://${company.website}`} target="_blank" rel="noopener noreferrer" className="hover:underline">{company.website}</a>
                </div>
                <div className="mt-2">
                  <img  alt={`شعار ${company.name}`} className="w-24 h-auto rounded" src={`https://source.unsplash.com/random/200x100/?logo,${company.logoSeed}`} />
                </div>
              </CardContent>
              <CardFooter className="flex justify-end gap-2 p-4 bg-secondary/30">
                <Button variant="outline" size="sm" className="text-blue-600 border-blue-600 hover:bg-blue-50">
                  <Edit2 className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="sm" className="text-red-600 border-red-600 hover:bg-red-50">
                  <Trash2 className="h-4 w-4" />
                </Button>
              </CardFooter>
            </Card>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
};

export default CustomersCompanies;