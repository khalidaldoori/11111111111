import React from 'react';
import { motion } from 'framer-motion';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { PlusCircle, CalendarDays, Building, User, Clock } from 'lucide-react';
import { Badge } from "@/components/ui/badge";

const sampleVisits = [
  { id: 1, companyName: "شركة السياحة العالمية", visitorName: "أحمد علي", visitDate: "2025-06-10", purpose: "مناقشة شراكة جديدة", status: "مجدولة" },
  { id: 2, companyName: "مجموعة فنادق النخبة", visitorName: "فاطمة حسن", visitDate: "2025-06-15", purpose: "عرض خدماتنا", status: "مكتملة" },
  { id: 3, companyName: "خدمات النقل السريع", visitorName: "خالد منصور", visitDate: "2025-06-20", purpose: "متابعة عرض سابق", status: "مؤجلة" },
];

const getStatusBadgeVariant = (status) => {
  switch (status) {
    case "مجدولة": return "default";
    case "مكتملة": return "success";
    case "مؤجلة": return "warning";
    case "ملغاة": return "destructive";
    default: return "secondary";
  }
};

const CustomersCompanyVisits = () => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <h1 className="text-3xl font-bold text-primary">زيارات الشركات</h1>
        <Button className="bg-primary hover:bg-primary/90 text-primary-foreground btn-glow">
          <PlusCircle className="ml-2 h-5 w-5" />
          جدولة زيارة جديدة
        </Button>
      </div>

      <div className="grid gap-6 md:grid-cols-1 lg:grid-cols-2">
        {sampleVisits.map((visit, index) => (
          <motion.div
            key={visit.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3, delay: index * 0.1 }}
          >
            <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300 card-hover">
              <CardHeader>
                <div className="flex justify-between items-start">
                  <CardTitle className="text-lg text-primary">{visit.purpose}</CardTitle>
                  <Badge variant={getStatusBadgeVariant(visit.status)}>{visit.status}</Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <div className="flex items-center text-muted-foreground">
                  <Building className="h-4 w-4 ml-2 text-primary" />
                  <span>الشركة: {visit.companyName}</span>
                </div>
                <div className="flex items-center text-muted-foreground">
                  <User className="h-4 w-4 ml-2 text-primary" />
                  <span>الزائر: {visit.visitorName}</span>
                </div>
                <div className="flex items-center text-muted-foreground">
                  <CalendarDays className="h-4 w-4 ml-2 text-primary" />
                  <span>تاريخ الزيارة: {visit.visitDate}</span>
                </div>
                 <div className="flex items-center text-muted-foreground">
                  <Clock className="h-4 w-4 ml-2 text-primary" />
                  <span>الوقت المتوقع: 10:00 صباحًا</span>
                </div>
                <img  alt={`اجتماع عمل في ${visit.companyName}`} className="w-full h-32 object-cover rounded-md mt-2" src={`https://source.unsplash.com/random/400x200/?business,meeting,${index}`} />
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
       {sampleVisits.length === 0 && (
        <p className="text-center text-muted-foreground py-8">لا توجد زيارات مجدولة حاليًا.</p>
      )}
    </motion.div>
  );
};

export default CustomersCompanyVisits;