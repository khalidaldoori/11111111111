import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { AlertTriangle } from 'lucide-react';

const NotFound = () => {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-desert-gradient text-white p-4 text-center">
      <motion.div
        initial={{ opacity: 0, scale: 0.5 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{
          duration: 0.8,
          delay: 0.2,
          ease: [0, 0.71, 0.2, 1.01]
        }}
        className="glass-effect p-8 md:p-12 rounded-xl shadow-2xl max-w-lg"
      >
        <motion.div
          animate={{ y: [0, -10, 0] }}
          transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
        >
          <AlertTriangle className="h-24 w-24 text-yellow-300 mx-auto mb-6" />
        </motion.div>
        
        <h1 className="text-6xl md:text-7xl font-bold mb-4">404</h1>
        <h2 className="text-2xl md:text-3xl font-semibold mb-3">عفواً، الصفحة غير موجودة!</h2>
        <p className="text-lg mb-8 text-yellow-100">
          يبدو أنك ضللت الطريق. الصفحة التي تبحث عنها إما تم حذفها أو لم تكن موجودة أصلاً.
        </p>
        <motion.div
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          <Button 
            asChild 
            size="lg" 
            className="bg-yellow-400 hover:bg-yellow-500 text-gray-900 font-semibold py-3 px-8 rounded-lg shadow-md transition-all duration-300 btn-glow"
          >
            <Link to="/">العودة إلى الصفحة الرئيسية</Link>
          </Button>
        </motion.div>
      </motion.div>
      <div className="absolute bottom-5 text-sm text-yellow-200/70">
        نظام إدارة شركة السياحة &copy; {new Date().getFullYear()}
      </div>
    </div>
  );
};

export default NotFound;