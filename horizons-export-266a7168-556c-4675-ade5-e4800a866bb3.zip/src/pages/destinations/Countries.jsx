import React from 'react';
import { motion } from 'framer-motion';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { PlusCircle, Edit, Trash2, Search, Globe, Users, MapPin } from 'lucide-react';
import { Input } from '@/components/ui/input';

const sampleCountries = [
  { id: 1, name: "فرنسا", continent: "أوروبا", capital: "باريس", population: "67 مليون", imageKey: "france_dest" },
  { id: 2, name: "اليابان", continent: "آسيا", capital: "طوكيو", population: "125 مليون", imageKey: "japan_dest" },
  { id: 3, name: "مصر", continent: "أفريقيا", capital: "القاهرة", population: "109 مليون", imageKey: "egypt_dest" },
  { id: 4, name: "البرازيل", continent: "أمريكا الجنوبية", capital: "برازيليا", population: "214 مليون", imageKey: "brazil_dest" },
];

const DestinationsCountries = () => {
  const [searchTerm, setSearchTerm] = React.useState('');

  const filteredCountries = sampleCountries.filter(country =>
    country.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    country.continent.toLowerCase().includes(searchTerm.toLowerCase()) ||
    country.capital.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <h1 className="text-3xl font-bold text-primary">إدارة الدول (الوجهات)</h1>
        <Button className="bg-primary hover:bg-primary/90 text-primary-foreground btn-glow">
          <PlusCircle className="ml-2 h-5 w-5" />
          إضافة دولة جديدة
        </Button>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
        <Input 
          type="text"
          placeholder="ابحث عن دولة..."
          className="pl-10 w-full md:w-1/2 lg:w-1/3 bg-background/80 border-border focus:ring-primary"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      {filteredCountries.length === 0 && (
        <p className="text-center text-muted-foreground py-8">لا توجد دول تطابق بحثك.</p>
      )}

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {filteredCountries.map((country, index) => (
          <motion.div
            key={country.id}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3, delay: index * 0.05 }}
          >
            <Card className="overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300 card-hover h-full flex flex-col">
              <div className="relative h-40 w-full">
                <img  
                  alt={`علم ${country.name}`} 
                  className="w-full h-full object-cover"
                  src={`https://source.unsplash.com/random/400x250/?flag,${country.imageKey}`}
                />
                 <div className="absolute bottom-2 left-2 bg-black/50 text-white px-2 py-1 text-xs rounded">
                  {country.continent}
                </div>
              </div>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg text-primary">{country.name}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-1 text-sm flex-grow">
                <div className="flex items-center text-muted-foreground">
                  <MapPin className="h-4 w-4 ml-1 text-red-500" />
                  العاصمة: {country.capital}
                </div>
                <div className="flex items-center text-muted-foreground">
                  <Users className="h-4 w-4 ml-1 text-green-500" />
                  السكان: {country.population}
                </div>
              </CardContent>
              <CardFooter className="flex justify-end gap-2 p-4 bg-secondary/30">
                <Button variant="outline" size="sm" className="text-blue-600 border-blue-600 hover:bg-blue-50">
                  <Edit className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="sm" className="text-red-600 border-red-600 hover:bg-red-50">
                  <Trash2 className="h-4 w-4" />
                </Button>
              </CardFooter>
            </Card>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
};

export default DestinationsCountries;