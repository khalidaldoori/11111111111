import React from 'react';
import { motion } from 'framer-motion';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { PlusCircle, Search, Filter, Plane, Users, CalendarDays, DollarSign } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

const sampleFlights = [
  { id: "FL001", airline: "الخطوط السعودية", from: "الرياض (RUH)", to: "باريس (CDG)", date: "2025-07-10", price: "2500 ر.س", status: "مجدولة" },
  { id: "FL002", airline: "طيران الإمارات", from: "دبي (DXB)", to: "لندن (LHR)", date: "2025-07-12", price: "3200 ر.س", status: "مؤكدة" },
  { id: "FL003", airline: "الخطوط الجوية القطرية", from: "الدوحة (DOH)", to: "نيويورك (JFK)", date: "2025-07-15", price: "4800 ر.س", status: "مغادرة" },
];

const getStatusBadgeVariantFlight = (status) => {
  if (status === "مؤكدة" || status === "مغادرة") return "success";
  if (status === "مجدولة") return "default";
  return "secondary";
};

const TransportationFlights = () => {
  const [searchTerm, setSearchTerm] = React.useState('');

  const filteredFlights = sampleFlights.filter(flight =>
    flight.airline.toLowerCase().includes(searchTerm.toLowerCase()) ||
    flight.from.toLowerCase().includes(searchTerm.toLowerCase()) ||
    flight.to.toLowerCase().includes(searchTerm.toLowerCase()) ||
    flight.id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <h1 className="text-3xl font-bold text-primary">إدارة حجوزات الطيران</h1>
        <div className="flex gap-2">
          <Button variant="outline" className="btn-glow">
            <Filter className="ml-2 h-4 w-4" />
            تصفية
          </Button>
          <Button className="bg-primary hover:bg-primary/90 text-primary-foreground btn-glow">
            <PlusCircle className="ml-2 h-5 w-5" />
            إضافة حجز طيران
          </Button>
        </div>
      </div>
      
      <Card className="shadow-lg">
        <CardHeader className="flex flex-col md:flex-row justify-between items-center gap-2">
           <div>
            <CardTitle className="text-xl text-primary">قائمة حجوزات الطيران</CardTitle>
            <CardDescription>عرض وإدارة جميع حجوزات الطيران.</CardDescription>
          </div>
          <div className="relative w-full md:w-auto">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
            <Input 
              type="text"
              placeholder="ابحث عن رحلة..."
              className="pl-10 w-full md:w-64 bg-background/80 border-border focus:ring-primary"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </CardHeader>
        <CardContent>
          {filteredFlights.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">لا توجد رحلات طيران تطابق بحثك.</p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>معرف الرحلة</TableHead>
                    <TableHead>شركة الطيران</TableHead>
                    <TableHead>من</TableHead>
                    <TableHead>إلى</TableHead>
                    <TableHead>التاريخ</TableHead>
                    <TableHead>السعر</TableHead>
                    <TableHead>الحالة</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredFlights.map((flight, index) => (
                    <motion.tr 
                      key={flight.id}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ duration: 0.3, delay: index * 0.05 }}
                      className="hover:bg-muted/50 transition-colors"
                    >
                      <TableCell className="font-medium">{flight.id}</TableCell>
                      <TableCell className="flex items-center gap-2">
                        <Plane className="h-4 w-4 text-blue-500" />
                        {flight.airline}
                      </TableCell>
                      <TableCell>{flight.from}</TableCell>
                      <TableCell>{flight.to}</TableCell>
                      <TableCell>{flight.date}</TableCell>
                      <TableCell className="font-semibold text-green-600">{flight.price}</TableCell>
                      <TableCell>
                        <Badge variant={getStatusBadgeVariantFlight(flight.status)}>{flight.status}</Badge>
                      </TableCell>
                    </motion.tr>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
      <div className="text-center mt-6">
         <img  alt="صورة طائرة تحلق في السماء" className="mx-auto w-1/2 max-w-md opacity-80 rounded-lg" src="https://images.unsplash.com/photo-1436491865332-7a61a109cc05" />
      </div>
    </motion.div>
  );
};

export default TransportationFlights;