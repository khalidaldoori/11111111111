import React from 'react';
import { motion } from 'framer-motion';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { PlusCircle, Search, Train, MapPin, Clock, Users, Ticket } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';

const sampleTrainJourneys = [
  { id: "TJ001", routeName: "الرياض - الدمام (قطار سريع)", operator: "سار (SAR)", departureStation: "محطة الرياض", arrivalStation: "محطة الدمام", duration: "4 ساعات", price: "250 ر.س", imageKey: "saudi_train_fast" },
  { id: "TJ002", routeName: "باريس - لندن (يوروستار)", operator: "Eurostar", departureStation: "Gare du Nord, Paris", arrivalStation: "St Pancras, London", duration: "2.5 ساعة", price: "120 يورو", imageKey: "eurostar_train_paris_london" },
  { id: "TJ003", routeName: "طوكيو - كيوتو (شينكانسن)", operator: "JR Central", departureStation: "محطة طوكيو", arrivalStation: "محطة كيوتو", duration: "2.2 ساعة", price: "13,000 ين", imageKey: "shinkansen_train_japan" },
];

const TransportationTrains = () => {
  const [searchTerm, setSearchTerm] = React.useState('');

  const filteredJourneys = sampleTrainJourneys.filter(item =>
    item.routeName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.operator.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.departureStation.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.arrivalStation.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <h1 className="text-3xl font-bold text-primary">إدارة رحلات القطارات</h1>
        <Button className="bg-primary hover:bg-primary/90 text-primary-foreground btn-glow">
          <PlusCircle className="ml-2 h-5 w-5" />
          إضافة رحلة قطار
        </Button>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
        <Input 
          type="text"
          placeholder="ابحث عن رحلة قطار..."
          className="pl-10 w-full md:w-1/2 lg:w-1/3 bg-background/80 border-border focus:ring-primary"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      {filteredJourneys.length === 0 && (
        <p className="text-center text-muted-foreground py-8">لا توجد رحلات قطارات تطابق بحثك.</p>
      )}

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {filteredJourneys.map((item, index) => (
          <motion.div
            key={item.id}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3, delay: index * 0.05 }}
          >
            <Card className="overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300 card-hover h-full flex flex-col">
              <div className="relative h-40 w-full">
                 <img  
                  alt={`قطار ${item.routeName}`} 
                  className="w-full h-full object-cover"
                  src={`https://source.unsplash.com/random/400x250/?train,${item.imageKey}`}
                />
                <Badge variant="outline" className="absolute top-2 right-2 bg-black/50 text-white">{item.operator}</Badge>
              </div>
              <CardHeader className="pb-2">
                <CardTitle className="text-md text-primary flex items-center gap-2">
                  <Train className="h-5 w-5" /> {item.routeName}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-1 text-sm flex-grow">
                <div className="flex items-center text-muted-foreground">
                  <MapPin className="h-4 w-4 ml-1" /> المغادرة: {item.departureStation}
                </div>
                <div className="flex items-center text-muted-foreground">
                  <MapPin className="h-4 w-4 ml-1" /> الوصول: {item.arrivalStation}
                </div>
                <div className="flex items-center text-muted-foreground">
                  <Clock className="h-4 w-4 ml-1" /> المدة: {item.duration}
                </div>
                 <div className="flex items-center text-muted-foreground">
                  <Ticket className="h-4 w-4 ml-1 text-green-600" /> السعر يبدأ من: {item.price}
                </div>
              </CardContent>
               <CardFooter className="flex justify-end gap-2 p-4 bg-secondary/30">
                <Button variant="outline" size="sm" className="text-blue-600 border-blue-600 hover:bg-blue-50">Edit</Button>
                <Button variant="outline" size="sm" className="text-red-600 border-red-600 hover:bg-red-50">Delete</Button>
              </CardFooter>
            </Card>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
};

export default TransportationTrains;