import React from 'react';
import { motion } from 'framer-motion';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { PlusCircle, Search, Car, Bus, Edit, Trash2, Users, MapPin, Clock } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';

const sampleGroundTransport = [
  { id: "GT001", type: "سيارة خاصة", provider: "ليموزين الرياض", vehicle: "مرسيدس S-Class", capacity: 3, date: "2025-07-05", from: "مطار الملك خالد", to: "فندق الفيصلية", imageKey: "mercedes_transport" },
  { id: "GT002", type: "حافلة سياحية", provider: "جولات المدينة", vehicle: "حافلة مرسيدس توريزمو", capacity: 50, date: "2025-07-08", route: "جولة معالم جدة", imageKey: "bus_tour_jeddah" },
  { id: "GT003", type: "تأجير سيارة", provider: "Budget لتأجير السيارات", vehicle: "تويوتا كامري", capacity: 5, date: "2025-07-10", duration: "3 أيام", imageKey: "camry_rental" },
];

const GroundTransportIcon = ({ type }) => {
  if (type.includes("سيارة")) return <Car className="h-5 w-5 text-blue-600" />;
  if (type.includes("حافلة")) return <Bus className="h-5 w-5 text-green-600" />;
  return <Car className="h-5 w-5 text-gray-500" />;
};

const TransportationGround = () => {
  const [searchTerm, setSearchTerm] = React.useState('');

  const filteredTransport = sampleGroundTransport.filter(item =>
    item.type.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.provider.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.vehicle.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <h1 className="text-3xl font-bold text-primary">إدارة النقل البري</h1>
        <Button className="bg-primary hover:bg-primary/90 text-primary-foreground btn-glow">
          <PlusCircle className="ml-2 h-5 w-5" />
          إضافة خدمة نقل بري
        </Button>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
        <Input 
          type="text"
          placeholder="ابحث عن خدمة نقل بري..."
          className="pl-10 w-full md:w-1/2 lg:w-1/3 bg-background/80 border-border focus:ring-primary"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      {filteredTransport.length === 0 && (
        <p className="text-center text-muted-foreground py-8">لا توجد خدمات نقل بري تطابق بحثك.</p>
      )}

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {filteredTransport.map((item, index) => (
          <motion.div
            key={item.id}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3, delay: index * 0.05 }}
          >
            <Card className="overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300 card-hover h-full flex flex-col">
              <div className="relative h-40 w-full">
                 <img  
                  alt={`${item.type} - ${item.vehicle}`} 
                  className="w-full h-full object-cover"
                  src={`https://source.unsplash.com/random/400x250/?${item.imageKey},transport`}
                />
                <Badge variant="secondary" className="absolute top-2 right-2 bg-black/60 text-white">{item.type}</Badge>
              </div>
              <CardHeader className="pb-2">
                <CardTitle className="text-md text-primary flex items-center gap-2">
                  <GroundTransportIcon type={item.type} /> {item.vehicle}
                </CardTitle>
                <CardDescription className="text-xs text-muted-foreground">المزود: {item.provider}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-1 text-sm flex-grow">
                <div className="flex items-center text-muted-foreground">
                  <Users className="h-4 w-4 ml-1" /> السعة: {item.capacity} أفراد
                </div>
                <div className="flex items-center text-muted-foreground">
                  <Clock className="h-4 w-4 ml-1" /> التاريخ: {item.date} {item.duration ? `(${item.duration})` : ''}
                </div>
                {item.from && item.to && (
                  <div className="flex items-center text-muted-foreground">
                    <MapPin className="h-4 w-4 ml-1" /> من: {item.from} إلى: {item.to}
                  </div>
                )}
                {item.route && (
                  <div className="flex items-center text-muted-foreground">
                    <MapPin className="h-4 w-4 ml-1" /> المسار: {item.route}
                  </div>
                )}
              </CardContent>
              <CardFooter className="flex justify-end gap-2 p-4 bg-secondary/30">
                <Button variant="outline" size="sm" className="text-blue-600 border-blue-600 hover:bg-blue-50">
                  <Edit className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="sm" className="text-red-600 border-red-600 hover:bg-red-50">
                  <Trash2 className="h-4 w-4" />
                </Button>
              </CardFooter>
            </Card>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
};

export default TransportationGround;