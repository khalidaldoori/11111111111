import React from 'react';
import { motion } from 'framer-motion';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { PlusCircle, Search, Ship, Anchor, Waves, CalendarDays, Users } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';

const sampleSeaTravels = [
  { id: "ST001", type: "رحلة بحرية فاخرة", vesselName: "ملكة البحار", departurePort: "ميناء ميامي", arrivalPort: "جزر البهاما", duration: "7 أيام", operator: "رويال كاريبيان", imageKey: "luxury_cruise_ship" },
  { id: "ST002", type: "عبّارة سريعة", vesselName: "النورس السريع", departurePort: "ميناء جدة الإسلامي", arrivalPort: "ميناء ضباء", duration: "3 ساعات", operator: "الشركة الوطنية للعبارات", imageKey: "fast_ferry" },
  { id: "ST003", type: "يخت خاص", vesselName: "الحرية", departurePort: "مرسى مارينا", arrivalPort: "جولة ساحلية", duration: "يوم واحد", operator: "تأجير يخوت خاصة", imageKey: "private_yacht_sea" },
];

const SeaTravelIcon = ({ type }) => {
  if (type.includes("رحلة بحرية")) return <Ship className="h-5 w-5 text-blue-700" />;
  if (type.includes("عبّارة")) return <Waves className="h-5 w-5 text-cyan-600" />;
  if (type.includes("يخت")) return <Anchor className="h-5 w-5 text-indigo-600" />;
  return <Ship className="h-5 w-5 text-gray-500" />;
};

const TransportationSea = () => {
  const [searchTerm, setSearchTerm] = React.useState('');

  const filteredTravels = sampleSeaTravels.filter(item =>
    item.type.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.vesselName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.departurePort.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.arrivalPort.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <h1 className="text-3xl font-bold text-primary">إدارة الرحلات البحرية</h1>
        <Button className="bg-primary hover:bg-primary/90 text-primary-foreground btn-glow">
          <PlusCircle className="ml-2 h-5 w-5" />
          إضافة رحلة بحرية
        </Button>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
        <Input 
          type="text"
          placeholder="ابحث عن رحلة بحرية..."
          className="pl-10 w-full md:w-1/2 lg:w-1/3 bg-background/80 border-border focus:ring-primary"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      {filteredTravels.length === 0 && (
        <p className="text-center text-muted-foreground py-8">لا توجد رحلات بحرية تطابق بحثك.</p>
      )}

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {filteredTravels.map((item, index) => (
          <motion.div
            key={item.id}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3, delay: index * 0.05 }}
          >
            <Card className="overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300 card-hover h-full flex flex-col">
              <div className="relative h-44 w-full">
                 <img  
                  alt={`${item.type} - ${item.vesselName}`} 
                  className="w-full h-full object-cover"
                  src={`https://source.unsplash.com/random/400x250/?${item.imageKey},sea`}
                />
                <Badge variant="default" className="absolute top-2 right-2 bg-primary/80 backdrop-blur-sm text-primary-foreground">{item.type}</Badge>
              </div>
              <CardHeader className="pb-2">
                <CardTitle className="text-md text-primary flex items-center gap-2">
                  <SeaTravelIcon type={item.type} /> {item.vesselName}
                </CardTitle>
                <CardDescription className="text-xs text-muted-foreground">المشغل: {item.operator}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-1 text-sm flex-grow">
                <div className="flex items-center text-muted-foreground">
                  <Anchor className="h-4 w-4 ml-1" /> ميناء المغادرة: {item.departurePort}
                </div>
                <div className="flex items-center text-muted-foreground">
                  <Anchor className="h-4 w-4 ml-1" /> ميناء الوصول: {item.arrivalPort}
                </div>
                <div className="flex items-center text-muted-foreground">
                  <CalendarDays className="h-4 w-4 ml-1" /> المدة: {item.duration}
                </div>
              </CardContent>
               <CardFooter className="flex justify-end gap-2 p-4 bg-secondary/30">
                <Button variant="outline" size="sm" className="text-blue-600 border-blue-600 hover:bg-blue-50">Edit</Button>
                <Button variant="outline" size="sm" className="text-red-600 border-red-600 hover:bg-red-50">Delete</Button>
              </CardFooter>
            </Card>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
};

export default TransportationSea;