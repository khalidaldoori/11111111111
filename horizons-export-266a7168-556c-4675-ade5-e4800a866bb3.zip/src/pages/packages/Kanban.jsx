import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { PlusCircle, GripVertical, UserCircle, Calendar, DollarSign, Layers } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

const initialColumns = {
  new: {
    name: "طلبات جديدة",
    color: "bg-blue-500",
    items: [
      { id: "task-1", content: "باقة شهر عسل لـ 'عائلة الفلاني'", client: "أحمد الفلاني", avatar: "new_client1", date: "2025-07-01", budget: "15,000 ر.س" },
      { id: "task-2", content: "رحلة عمل لـ 'شركة النجوم'", client: "شركة النجوم", avatar: "new_client2", date: "2025-08-10", budget: "50,000 ر.س" },
    ],
  },
  planning: {
    name: "قيد التخطيط",
    color: "bg-yellow-500",
    items: [
      { id: "task-3", content: "تخطيط رحلة أوروبية لـ 'محمد علي'", client: "محمد علي", avatar: "planning_client1", date: "2025-07-15", budget: "25,000 ر.س" },
    ],
  },
  proposalSent: {
    name: "تم إرسال العرض",
    color: "bg-purple-500",
    items: [
      { id: "task-4", content: "عرض رحلة المالديف لـ 'سارة خالد'", client: "سارة خالد", avatar: "proposal_client1", date: "2025-06-20", budget: "18,000 ر.س" },
    ],
  },
  confirmed: {
    name: "مؤكدة",
    color: "bg-green-500",
    items: [
      { id: "task-5", content: "باقة اليابان لـ 'خالد عبدالله'", client: "خالد عبدالله", avatar: "confirmed_client1", date: "2025-09-01", budget: "30,000 ر.س" },
    ],
  },
};

const KanbanTask = ({ task, columnId }) => {
  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 10 }}
      transition={{ duration: 0.2 }}
      className="p-3 mb-3 bg-card rounded-lg shadow-md border border-border cursor-grab active:cursor-grabbing"
      draggable
      onDragStart={(e) => {
        e.dataTransfer.setData("taskId", task.id);
        e.dataTransfer.setData("sourceColumnId", columnId);
      }}
    >
      <div className="flex items-center justify-between mb-2">
        <h4 className="text-sm font-semibold text-foreground">{task.content}</h4>
        <GripVertical className="h-4 w-4 text-muted-foreground" />
      </div>
      <div className="flex items-center space-x-2 rtl:space-x-reverse text-xs text-muted-foreground mb-1">
        <Avatar className="h-6 w-6">
          <AvatarImage src={`https://source.unsplash.com/random/50x50/?avatar,${task.avatar}`} />
          <AvatarFallback>{task.client.substring(0,1)}</AvatarFallback>
        </Avatar>
        <span>{task.client}</span>
      </div>
      <div className="flex items-center text-xs text-muted-foreground mb-1">
        <Calendar className="h-3 w-3 ml-1 text-primary" />
        <span>{task.date}</span>
      </div>
      <div className="flex items-center text-xs text-muted-foreground">
        <DollarSign className="h-3 w-3 ml-1 text-green-500" />
        <span>{task.budget}</span>
      </div>
    </motion.div>
  );
};

const KanbanColumn = ({ column, columnId, items, onDrop }) => {
  return (
    <div 
      className="bg-secondary/70 p-4 rounded-lg w-full md:w-72 flex-shrink-0 h-full min-h-[300px]"
      onDragOver={(e) => e.preventDefault()}
      onDrop={(e) => {
        e.preventDefault();
        onDrop(columnId, e);
      }}
    >
      <div className={`flex items-center justify-between mb-4 p-2 rounded-md text-white ${column.color}`}>
        <h3 className="font-semibold text-sm">{column.name}</h3>
        <Layers className="h-4 w-4" />
      </div>
      <div className="space-y-3 min-h-[200px]">
        <AnimatePresence>
          {items.map(task => (
            <KanbanTask key={task.id} task={task} columnId={columnId} />
          ))}
        </AnimatePresence>
        {items.length === 0 && (
          <div className="text-center text-xs text-muted-foreground py-4">
            لا توجد مهام في هذه المرحلة.
          </div>
        )}
      </div>
    </div>
  );
};

const PackagesKanban = () => {
  const [columns, setColumns] = useState(initialColumns);

  const handleDrop = (targetColumnId, e) => {
    const taskId = e.dataTransfer.getData("taskId");
    const sourceColumnId = e.dataTransfer.getData("sourceColumnId");

    if (sourceColumnId === targetColumnId) return;

    const taskToMove = columns[sourceColumnId].items.find(item => item.id === taskId);
    
    setColumns(prev => ({
      ...prev,
      [sourceColumnId]: {
        ...prev[sourceColumnId],
        items: prev[sourceColumnId].items.filter(item => item.id !== taskId),
      },
      [targetColumnId]: {
        ...prev[targetColumnId],
        items: [...prev[targetColumnId].items, taskToMove],
      },
    }));
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <h1 className="text-3xl font-bold text-primary">لوحة كانبان لمتابعة العروض المخصصة</h1>
        <Button className="bg-primary hover:bg-primary/90 text-primary-foreground btn-glow">
          <PlusCircle className="ml-2 h-5 w-5" />
          إضافة طلب جديد
        </Button>
      </div>

      <div className="flex flex-col md:flex-row gap-6 overflow-x-auto pb-4">
        {Object.entries(columns).map(([columnId, column]) => (
          <KanbanColumn 
            key={columnId} 
            column={column} 
            columnId={columnId} 
            items={column.items} 
            onDrop={handleDrop}
          />
        ))}
      </div>
      <img  alt="رسم توضيحي لمراحل العمل في لوحة كانبان" className="w-full max-w-xl mx-auto mt-4 opacity-70" src="https://images.unsplash.com/photo-1552664730-d307ca884978" />
    </motion.div>
  );
};

export default PackagesKanban;