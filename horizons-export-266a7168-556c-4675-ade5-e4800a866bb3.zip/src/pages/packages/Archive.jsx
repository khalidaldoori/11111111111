import React from 'react';
import { motion } from 'framer-motion';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Archive, Search, Filter, Package, CalendarCheck, RotateCcw, Eye } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

const sampleArchivedOffers = [
  { id: "ARC001", name: "عرض الصيف الأوروبي 2024", type: "باقة موسمية", originalPrice: "8500 ر.س", archiveDate: "2024-09-01", reason: "انتهاء الموسم" },
  { id: "ARC002", name: "رحلة استكشاف آسيا (مجموعة)", type: "باقة جماعية", originalPrice: "12000 ر.س", archiveDate: "2024-10-15", reason: "تم الاستبدال بعرض أحدث" },
  { id: "ARC003", name: "عطلة نهاية الأسبوع في إسطنبول", type: "عرض قصير", originalPrice: "2200 ر.س", archiveDate: "2024-08-20", reason: "غير متوفر حالياً" },
];

const PackagesArchive = () => {
  const [searchTerm, setSearchTerm] = React.useState('');

  const filteredOffers = sampleArchivedOffers.filter(offer =>
    offer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    offer.type.toLowerCase().includes(searchTerm.toLowerCase()) ||
    offer.id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <div className="flex items-center gap-2">
          <Archive className="h-8 w-8 text-primary" />
          <h1 className="text-3xl font-bold text-primary">أرشيف العروض والباقات</h1>
        </div>
        <Button variant="outline" className="btn-glow">
          <Filter className="ml-2 h-4 w-4" />
          تصفية الأرشيف
        </Button>
      </div>

      <Card className="shadow-lg">
        <CardHeader className="flex flex-col md:flex-row justify-between items-center gap-2">
           <div>
            <CardTitle className="text-xl text-primary">العروض المؤرشفة</CardTitle>
            <CardDescription>قائمة بالعروض والباقات التي تم أرشفتها ولم تعد متاحة للحجز.</CardDescription>
          </div>
          <div className="relative w-full md:w-auto">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
            <Input 
              type="text"
              placeholder="ابحث في الأرشيف..."
              className="pl-10 w-full md:w-64 bg-background/80 border-border focus:ring-primary"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </CardHeader>
        <CardContent>
          {filteredOffers.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">لا توجد عروض مؤرشفة تطابق بحثك.</p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>المعرف</TableHead>
                    <TableHead>اسم العرض/الباقة</TableHead>
                    <TableHead>النوع</TableHead>
                    <TableHead>السعر الأصلي</TableHead>
                    <TableHead>تاريخ الأرشفة</TableHead>
                    <TableHead>سبب الأرشفة</TableHead>
                    <TableHead className="text-left">إجراءات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredOffers.map((offer, index) => (
                    <motion.tr 
                      key={offer.id}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ duration: 0.3, delay: index * 0.05 }}
                      className="hover:bg-muted/50 transition-colors"
                    >
                      <TableCell className="font-medium">{offer.id}</TableCell>
                      <TableCell className="flex items-center gap-2">
                        <Package className="h-4 w-4 text-muted-foreground" />
                        {offer.name}
                      </TableCell>
                      <TableCell>
                        <Badge variant="secondary">{offer.type}</Badge>
                      </TableCell>
                      <TableCell>{offer.originalPrice}</TableCell>
                      <TableCell className="flex items-center gap-1">
                        <CalendarCheck className="h-4 w-4 text-muted-foreground" />
                        {offer.archiveDate}
                      </TableCell>
                      <TableCell>{offer.reason}</TableCell>
                      <TableCell className="text-left space-x-1 rtl:space-x-reverse">
                        <Button variant="ghost" size="icon" title="عرض التفاصيل" className="text-primary hover:text-primary/80">
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" title="إعادة تفعيل (إذا أمكن)" className="text-green-600 hover:text-green-700">
                          <RotateCcw className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </motion.tr>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
       <div className="text-center mt-6">
        <img  alt="صورة لأرشيف ملفات" className="mx-auto w-1/3 max-w-xs opacity-50" src="https://images.unsplash.com/photo-1584433144850-532aca64a032" />
      </div>
    </motion.div>
  );
};

export default PackagesArchive;