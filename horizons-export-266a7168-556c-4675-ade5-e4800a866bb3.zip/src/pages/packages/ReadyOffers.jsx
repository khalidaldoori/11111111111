import React from 'react';
import { motion } from 'framer-motion';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { PlusCircle, Edit, Trash2, Search, Package, DollarSign, Clock, Tag } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';

const sampleOffers = [
  { id: 1, name: "باقة باريس الساحرة", destination: "باريس, فرنسا", duration: "5 أيام / 4 ليالي", price: "3500 ر.س", type: "ترفيهي", validity: "حتى 30 سبتمبر 2025", imageKey: "paris_offer" },
  { id: 2, name: "مغامرة دبي الفاخرة", destination: "دبي, الإمارات", duration: "3 أيام / 2 ليلتان", price: "2800 ر.س", type: "فاخر", validity: "حتى 15 أغسطس 2025", imageKey: "dubai_offer" },
  { id: 3, name: "استكشاف طبيعة سويسرا", destination: "إنترلاكن, سويسرا", duration: "7 أيام / 6 ليالي", price: "7200 ر.س", type: "طبيعة ومغامرة", validity: "حتى 31 أكتوبر 2025", imageKey: "swiss_offer" },
];

const ReadyOffers = () => {
  const [searchTerm, setSearchTerm] = React.useState('');

  const filteredOffers = sampleOffers.filter(offer => 
    offer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    offer.destination.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <h1 className="text-3xl font-bold text-primary">العروض الجاهزة</h1>
        <Button className="bg-primary hover:bg-primary/90 text-primary-foreground btn-glow">
          <PlusCircle className="ml-2 h-5 w-5" />
          إضافة عرض جديد
        </Button>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
        <Input 
          type="text"
          placeholder="ابحث عن عرض..."
          className="pl-10 w-full md:w-1/2 lg:w-1/3 bg-background/80 border-border focus:ring-primary"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      {filteredOffers.length === 0 && (
        <p className="text-center text-muted-foreground py-8">لا توجد عروض تطابق بحثك.</p>
      )}

      <div className="grid gap-6 md:grid-cols-1 lg:grid-cols-2 xl:grid-cols-3">
        {filteredOffers.map((offer, index) => (
          <motion.div
            key={offer.id}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3, delay: index * 0.05 }}
          >
            <Card className="overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300 card-hover h-full flex flex-col">
              <div className="relative h-52 w-full">
                <img  
                  alt={offer.name} 
                  className="w-full h-full object-cover"
                  src={`https://source.unsplash.com/random/400x300/?travel,${offer.imageKey}`} 
                />
                <Badge className="absolute top-2 right-2 bg-primary/80 backdrop-blur-sm text-primary-foreground">{offer.type}</Badge>
              </div>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg text-primary">{offer.name}</CardTitle>
                <CardDescription className="text-sm text-muted-foreground">{offer.destination}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-2 text-sm flex-grow">
                <div className="flex items-center text-muted-foreground">
                  <DollarSign className="h-4 w-4 ml-1 text-green-500" />
                  السعر: <span className="font-semibold text-foreground mr-1">{offer.price}</span>
                </div>
                <div className="flex items-center text-muted-foreground">
                  <Clock className="h-4 w-4 ml-1 text-blue-500" />
                  المدة: {offer.duration}
                </div>
                 <div className="flex items-center text-muted-foreground">
                  <Tag className="h-4 w-4 ml-1 text-purple-500" />
                  الصلاحية: {offer.validity}
                </div>
              </CardContent>
              <CardFooter className="flex justify-end gap-2 p-4 bg-secondary/30">
                <Button variant="outline" size="sm" className="text-blue-600 border-blue-600 hover:bg-blue-50">
                  <Edit className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="sm" className="text-red-600 border-red-600 hover:bg-red-50">
                  <Trash2 className="h-4 w-4" />
                </Button>
              </CardFooter>
            </Card>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
};

export default ReadyOffers;