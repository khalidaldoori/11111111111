import React from 'react';
import { motion } from 'framer-motion';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { PlusCircle, FileText, Edit, Eye, Settings2 } from 'lucide-react';

const bookingFormats = [
  { id: 1, name: "نموذج حجز فندقي أساسي", type: "فنادق", fields: 10, lastUpdated: "2025-05-01", active: true, iconKey:"hotel" },
  { id: 2, name: "نموذج حجز طيران دولي", type: "طيران", fields: 15, lastUpdated: "2025-04-20", active: true, iconKey:"flight" },
  { id: 3, name: "نموذج حجز باقة سياحية متكاملة", type: "باقات", fields: 25, lastUpdated: "2025-05-15", active: true, iconKey:"package" },
  { id: 4, name: "نموذج حجز رحلة بحرية", type: "رحلات بحرية", fields: 12, lastUpdated: "2025-03-10", active: false, iconKey:"cruise" },
  { id: 5, name: "نموذج طلب تأشيرة", type: "تأشيرات", fields: 18, lastUpdated: "2025-06-01", active: true, iconKey:"visa" },
  { id: 6, name: "نموذج حجز سيارة", type: "نقل بري", fields: 8, lastUpdated: "2025-02-25", active: true, iconKey:"car" },
  { id: 7, name: "نموذج حجز جولة سياحية", type: "خدمات", fields: 9, lastUpdated: "2025-05-22", active: false, iconKey:"tour" },
];

const BookingFormats = () => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <h1 className="text-3xl font-bold text-primary">تنسيقات الحجز (7 أنواع)</h1>
        <Button className="bg-primary hover:bg-primary/90 text-primary-foreground btn-glow">
          <PlusCircle className="ml-2 h-5 w-5" />
          إنشاء تنسيق جديد
        </Button>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {bookingFormats.map((format, index) => (
          <motion.div
            key={format.id}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3, delay: index * 0.05 }}
          >
            <Card className={`shadow-lg hover:shadow-xl transition-shadow duration-300 card-hover h-full flex flex-col ${!format.active ? 'opacity-70 bg-gray-50' : ''}`}>
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <CardTitle className="text-md text-primary flex items-center gap-2">
                    <FileText className="h-5 w-5" />
                    {format.name}
                  </CardTitle>
                  <span className={`px-2 py-0.5 text-xs rounded-full ${format.active ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                    {format.active ? "نشط" : "غير نشط"}
                  </span>
                </div>
              </CardHeader>
              <CardContent className="space-y-2 text-sm flex-grow">
                <p className="text-muted-foreground">النوع: <span className="font-medium text-foreground">{format.type}</span></p>
                <p className="text-muted-foreground">عدد الحقول: <span className="font-medium text-foreground">{format.fields}</span></p>
                <p className="text-muted-foreground">آخر تحديث: <span className="font-medium text-foreground">{format.lastUpdated}</span></p>
                <img  alt={`أيقونة تنسيق ${format.name}`} className="w-full h-24 object-contain mt-2 opacity-60" src={`https://source.unsplash.com/random/300x100/?form,document,${format.iconKey}`} />
              </CardContent>
              <div className="p-4 bg-secondary/30 border-t flex justify-end gap-2">
                <Button variant="ghost" size="icon" className="text-gray-600 hover:text-primary">
                  <Eye className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="icon" className="text-blue-600 hover:text-blue-700">
                  <Edit className="h-4 w-4" />
                </Button>
                 <Button variant="ghost" size="icon" className="text-orange-600 hover:text-orange-700">
                  <Settings2 className="h-4 w-4" />
                </Button>
              </div>
            </Card>
          </motion.div>
        ))}
      </div>
      {bookingFormats.length === 0 && (
        <p className="text-center text-muted-foreground py-8">لا توجد تنسيقات حجز معرفة.</p>
      )}
    </motion.div>
  );
};

export default BookingFormats;