import React from 'react';
import { motion } from 'framer-motion';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { PlusCircle, Edit, Search, PackagePlus, User, CalendarDays, DollarSign, ListChecks } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

const sampleCustomPackages = [
  { id: "CP001", clientName: "أحمد الهاشمي", avatarSeed: "ahmed_custom", destinations: "لندن, باريس", creationDate: "2025-05-20", totalPrice: "15000 ر.س", status: "قيد المراجعة" },
  { id: "CP002", clientName: "شركة التقنية المتقدمة", avatarSeed: "tech_custom", destinations: "سنغافورة, طوكيو (رحلة عمل)", creationDate: "2025-05-15", totalPrice: "45000 ر.س", status: "مؤكدة" },
  { id: "CP003", clientName: "عائلة السالمي", avatarSeed: "salmi_custom", destinations: "جزر المالديف (شهر عسل)", creationDate: "2025-06-01", totalPrice: "25000 ر.س", status: "تم إرسال العرض" },
];

const getStatusBadgeVariant = (status) => {
  if (status === "مؤكدة") return "success";
  if (status === "قيد المراجعة") return "warning";
  if (status === "تم إرسال العرض") return "default";
  return "secondary";
};

const CustomPackages = () => {
  const [searchTerm, setSearchTerm] = React.useState('');

  const filteredPackages = sampleCustomPackages.filter(pkg => 
    pkg.clientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    pkg.destinations.toLowerCase().includes(searchTerm.toLowerCase()) ||
    pkg.id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <h1 className="text-3xl font-bold text-primary">الباقات المخصصة</h1>
        <Button className="bg-primary hover:bg-primary/90 text-primary-foreground btn-glow">
          <PackagePlus className="ml-2 h-5 w-5" />
          إنشاء باقة مخصصة
        </Button>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
        <Input 
          type="text"
          placeholder="ابحث عن باقة مخصصة (بالعميل, الوجهة, المعرف)..."
          className="pl-10 w-full md:w-1/2 lg:w-1/3 bg-background/80 border-border focus:ring-primary"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      {filteredPackages.length === 0 && (
        <p className="text-center text-muted-foreground py-8">لا توجد باقات مخصصة تطابق بحثك.</p>
      )}

      <div className="grid gap-6 md:grid-cols-1 lg:grid-cols-2 xl:grid-cols-3">
        {filteredPackages.map((pkg, index) => (
          <motion.div
            key={pkg.id}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3, delay: index * 0.05 }}
          >
            <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300 card-hover h-full flex flex-col">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3 rtl:space-x-reverse">
                    <Avatar className="h-10 w-10">
                       <AvatarImage src={`https://source.unsplash.com/random/80x80/?client,${pkg.avatarSeed}`} alt={pkg.clientName} />
                       <AvatarFallback>{pkg.clientName.substring(0,1)}</AvatarFallback>
                    </Avatar>
                    <CardTitle className="text-md text-primary">{pkg.clientName}</CardTitle>
                  </div>
                   <Badge variant={getStatusBadgeVariant(pkg.status)}>{pkg.status}</Badge>
                </div>
                <CardDescription className="text-xs text-muted-foreground pt-1">معرف الباقة: {pkg.id}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-2 text-sm flex-grow">
                <div className="flex items-center text-muted-foreground">
                  <ListChecks className="h-4 w-4 ml-1 text-blue-500" />
                  الوجهات: <span className="font-semibold text-foreground mr-1">{pkg.destinations}</span>
                </div>
                <div className="flex items-center text-muted-foreground">
                  <CalendarDays className="h-4 w-4 ml-1 text-green-500" />
                  تاريخ الإنشاء: {pkg.creationDate}
                </div>
                <div className="flex items-center text-muted-foreground">
                  <DollarSign className="h-4 w-4 ml-1 text-red-500" />
                  السعر الإجمالي: <span className="font-semibold text-foreground mr-1">{pkg.totalPrice}</span>
                </div>
                <img  alt={`صورة تعبر عن باقة ${pkg.clientName}`} className="w-full h-28 object-cover rounded-md mt-3" src={`https://source.unsplash.com/random/400x200/?travel,luxury,${index}`} />
              </CardContent>
              <CardFooter className="flex justify-end gap-2 p-4 bg-secondary/30">
                <Button variant="outline" size="sm" className="text-blue-600 border-blue-600 hover:bg-blue-50">
                  <Edit className="h-4 w-4" />
                </Button>
              </CardFooter>
            </Card>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
};

export default CustomPackages;