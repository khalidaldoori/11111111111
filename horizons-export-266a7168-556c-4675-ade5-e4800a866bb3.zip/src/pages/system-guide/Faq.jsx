import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { HelpCircle, Search, MessageCircle } from 'lucide-react';
import { Input } from '@/components/ui/input';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const faqItems = [
  { 
    question: "كيف يمكنني إضافة عميل جديد إلى النظام؟", 
    answer: "يمكنك إضافة عميل جديد بالانتقال إلى قسم 'إدارة العملاء'، ثم اختيار 'الأشخاص' أو 'الشركات'، والنقر على زر 'إضافة جديد'. قم بملء الحقول المطلوبة واحفظ البيانات." 
  },
  { 
    question: "ما هي طريقة إنشاء باقة سياحية مخصصة؟", 
    answer: "لإنشاء باقة مخصصة، اذهب إلى 'العروض والباقات' ثم 'الباقات المخصصة'. انقر على 'إنشاء باقة مخصصة' وأدخل تفاصيل طلب العميل مثل الوجهات، الفنادق، الرحلات، والخدمات الإضافية. يمكنك بعد ذلك إرسال العرض للعميل." 
  },
  { 
    question: "كيف أتابع حالة طلب تأشيرة؟", 
    answer: "لمتابعة طلبات التأشيرات، انتقل إلى قسم 'إدارة التأشيرات' ثم 'طلبات التأشيرات'. ستجد قائمة بجميع الطلبات وحالتها الحالية (مثل: قيد المراجعة، موافق عليها، مرفوضة)." 
  },
  { 
    question: "هل يمكنني تصدير التقارير المالية؟", 
    answer: "نعم، يمكنك تصدير التقارير المالية. اذهب إلى 'النظام المالي' ثم اختر نوع التقرير الذي تريده (مثل: الفواتير، المصروفات). عادةً ما يكون هناك زر 'تصدير' يسمح لك بحفظ التقرير بصيغة PDF أو Excel." 
  },
  { 
    question: "كيف أغير كلمة المرور الخاصة بي؟", 
    answer: "لتغيير كلمة المرور، اذهب إلى 'الإعدادات' ثم 'إعدادات الملف الشخصي'. ستجد حقلًا لإدخال كلمة المرور الجديدة. أدخل كلمة المرور الجديدة وأكدها، ثم احفظ التغييرات." 
  },
];

const SystemGuideFaq = () => {
  const [searchTerm, setSearchTerm] = React.useState('');

  const filteredFaqs = faqItems.filter(faq =>
    faq.question.toLowerCase().includes(searchTerm.toLowerCase()) ||
    faq.answer.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <div className="flex items-center gap-3">
          <HelpCircle className="h-8 w-8 text-primary" />
          <h1 className="text-3xl font-bold text-primary">الأسئلة الشائعة (FAQ)</h1>
        </div>
         <div className="relative w-full md:w-auto">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
            <Input 
              type="text"
              placeholder="ابحث في الأسئلة الشائعة..."
              className="pl-10 w-full md:w-64 bg-background/80 border-border focus:ring-primary"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
      </div>
      
      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="text-xl text-primary">أكثر الأسئلة شيوعاً وإجاباتها</CardTitle>
          <CardDescription>تجد هنا إجابات سريعة لأكثر الاستفسارات شيوعًا حول استخدام النظام.</CardDescription>
        </CardHeader>
        <CardContent>
          {filteredFaqs.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">لا توجد أسئلة تطابق بحثك.</p>
          ) : (
             <Accordion type="single" collapsible className="w-full space-y-3">
              {filteredFaqs.map((faq, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.2, delay: index * 0.05 }}
                >
                  <AccordionItem value={`item-${index}`} className="bg-card border border-border rounded-lg shadow-sm hover:shadow-md transition-shadow">
                    <AccordionTrigger className="p-4 text-primary hover:no-underline text-right">
                      <div className="flex items-center gap-3">
                         <MessageCircle className="h-5 w-5 text-muted-foreground" />
                        <span className="font-semibold">{faq.question}</span>
                      </div>
                    </AccordionTrigger>
                    <AccordionContent className="p-4 pt-0 text-sm text-muted-foreground">
                      {faq.answer}
                    </AccordionContent>
                  </AccordionItem>
                </motion.div>
              ))}
            </Accordion>
          )}
        </CardContent>
      </Card>
      <div className="text-center mt-6">
         <img  alt="أيقونات أسئلة وأجوبة" className="mx-auto w-1/3 max-w-xs opacity-60" src="https://images.unsplash.com/photo-1581078349546-3f7390984738" />
      </div>
    </motion.div>
  );
};

export default SystemGuideFaq;