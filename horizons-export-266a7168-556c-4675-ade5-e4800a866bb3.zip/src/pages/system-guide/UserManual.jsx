import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { BookOpen, Search, Users, Package, Settings, FileText } from 'lucide-react';
import { Input } from '@/components/ui/input';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const manualSections = [
  { 
    title: "مقدمة عن النظام", 
    icon: <BookOpen className="h-5 w-5 text-primary" />,
    content: "مرحباً بك في دليل مستخدم نظام إدارة شركة السياحة. هذا الدليل مصمم لمساعدتك على فهم واستخدام جميع ميزات النظام بكفاءة لتحقيق أفضل النتائج لأعمالك." 
  },
  { 
    title: "إدارة العملاء", 
    icon: <Users className="h-5 w-5 text-blue-500" />,
    content: "يشرح هذا القسم كيفية إضافة وتعديل بيانات العملاء (الأفراد والشركات)، تسجيل زيارات الشركات، متابعة حالات الزيارات، وإدارة سجل التواصل مع العملاء لتقديم خدمة متميزة." 
  },
  { 
    title: "إدارة العروض والباقات", 
    icon: <Package className="h-5 w-5 text-green-500" />,
    content: "تعرف على كيفية إنشاء وإدارة العروض الجاهزة والباقات المخصصة، استخدام تنسيقات الحجز المختلفة، متابعة الطلبات عبر لوحة كانبان، وأرشفة العروض المنتهية." 
  },
  { 
    title: "إدارة الحجوزات والوجهات", 
    icon: <FileText className="h-5 w-5 text-purple-500" />,
    content: "هنا تجد معلومات حول تسجيل وتتبع الحجوزات، إدارة الدول والمدن والمعالم السياحية، وإدارة معلومات الإقامة والنقل المختلفة لضمان تجربة سفر سلسة لعملائك." 
  },
  { 
    title: "الإعدادات والتقارير", 
    icon: <Settings className="h-5 w-5 text-red-500" />,
    content: "يوضح هذا الجزء كيفية تخصيص إعدادات النظام، إدارة المستخدمين والصلاحيات، واستخراج التقارير والإحصائيات المتنوعة لمتابعة أداء الشركة واتخاذ قرارات مستنيرة." 
  },
];

const SystemGuideUserManual = () => {
  const [searchTerm, setSearchTerm] = React.useState('');

  const filteredSections = manualSections.filter(section =>
    section.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    section.content.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <div className="flex items-center gap-3">
          <BookOpen className="h-8 w-8 text-primary" />
          <h1 className="text-3xl font-bold text-primary">دليل المستخدم</h1>
        </div>
        <div className="relative w-full md:w-auto">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
            <Input 
              type="text"
              placeholder="ابحث في الدليل..."
              className="pl-10 w-full md:w-64 bg-background/80 border-border focus:ring-primary"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
      </div>
      
      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="text-xl text-primary">أقسام الدليل</CardTitle>
          <CardDescription>تصفح الأقسام المختلفة لمعرفة المزيد عن وظائف النظام.</CardDescription>
        </CardHeader>
        <CardContent>
          {filteredSections.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">لا توجد أقسام تطابق بحثك.</p>
          ) : (
             <Accordion type="single" collapsible className="w-full space-y-3">
              {filteredSections.map((section, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.2, delay: index * 0.05 }}
                >
                  <AccordionItem value={`item-${index}`} className="bg-secondary/30 border border-border rounded-lg shadow-sm hover:shadow-md transition-shadow">
                    <AccordionTrigger className="p-4 text-primary hover:no-underline">
                      <div className="flex items-center gap-3">
                        {section.icon}
                        <span className="font-semibold">{section.title}</span>
                      </div>
                    </AccordionTrigger>
                    <AccordionContent className="p-4 pt-0 text-sm text-muted-foreground">
                      {section.content}
                       <img  alt={`رسم توضيحي لقسم ${section.title}`} className="w-full h-32 object-contain mt-3 rounded-md opacity-70" src={`https://source.unsplash.com/random/400x150/?guidebook,manual,${index}`} />
                    </AccordionContent>
                  </AccordionItem>
                </motion.div>
              ))}
            </Accordion>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default SystemGuideUserManual;