import React from 'react';
import { motion } from 'framer-motion';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardFooter, CardDescription } from "@/components/ui/card";
import { PlusCircle, Edit, Trash2, Search, Palmtree, Waves, Sun, Star, MapPin } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';

const sampleResorts = [
  { id: 1, name: "منتجع فور سيزونز المالديف", location: "جزر المالديف", type: "شاطئي فاخر", rating: 5, activities: ["غوص", "سبا", "يوجا"], imageKey: "fourseasons_maldives_resort" },
  { id: 2, name: "منتجع سانت ريجيس بالي", location: "بالي, إندونيسيا", type: "استوائي ثقافي", rating: 5, activities: ["تصفح أمواج", "دروس طبخ", "جولات ثقافية"], imageKey: "stregis_bali_resort" },
  { id: 3, name: "منتجع بانيان تري بوكيت", location: "بوكيت, تايلاند", type: "استرخاء وعافية", rating: 4, activities: ["علاجات سبا", "غولف", "رياضات مائية"], imageKey: "banyantree_phuket_resort" },
];

const StarRatingResort = ({ count }) => (
  <div className="flex">
    {[...Array(count)].map((_, i) => (
      <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
    ))}
    {[...Array(5-count)].map((_, i) => (
      <Star key={`empty-${i}`} className="h-5 w-5 text-gray-300" />
    ))}
  </div>
);

const AccommodationResorts = () => {
  const [searchTerm, setSearchTerm] = React.useState('');

  const filteredResorts = sampleResorts.filter(resort =>
    resort.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    resort.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
    resort.type.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <h1 className="text-3xl font-bold text-primary">إدارة المنتجعات</h1>
        <Button className="bg-primary hover:bg-primary/90 text-primary-foreground btn-glow">
          <PlusCircle className="ml-2 h-5 w-5" />
          إضافة منتجع جديد
        </Button>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
        <Input 
          type="text"
          placeholder="ابحث عن منتجع..."
          className="pl-10 w-full md:w-1/2 lg:w-1/3 bg-background/80 border-border focus:ring-primary"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      {filteredResorts.length === 0 && (
        <p className="text-center text-muted-foreground py-8">لا توجد منتجعات تطابق بحثك.</p>
      )}

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {filteredResorts.map((resort, index) => (
          <motion.div
            key={resort.id}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3, delay: index * 0.05 }}
          >
            <Card className="overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300 card-hover h-full flex flex-col">
              <div className="relative h-52 w-full">
                <img  
                  alt={`صورة لـ ${resort.name}`} 
                  className="w-full h-full object-cover"
                  src={`https://source.unsplash.com/random/400x300/?resort,${resort.imageKey}`}
                />
                 <div className="absolute top-2 right-2">
                  <StarRatingResort count={resort.rating} />
                </div>
                <Badge variant="secondary" className="absolute bottom-2 left-2 bg-black/60 text-white">{resort.type}</Badge>
              </div>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg text-primary flex items-center gap-2">
                   <Palmtree className="h-5 w-5"/> {resort.name}
                </CardTitle>
                <CardDescription className="text-xs text-muted-foreground">
                    <MapPin className="inline h-3 w-3 mr-1"/>{resort.location}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-2 text-sm flex-grow">
                 <div>
                  <p className="text-muted-foreground mb-1">أبرز الأنشطة:</p>
                  <div className="flex flex-wrap gap-1">
                    {resort.activities.slice(0,3).map(activity => (
                      <Badge key={activity} variant="outline" className="text-xs">{activity}</Badge>
                    ))}
                    {resort.activities.length > 3 && <Badge variant="outline" className="text-xs">...</Badge>}
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex justify-end gap-2 p-4 bg-secondary/30">
                <Button variant="outline" size="sm" className="text-blue-600 border-blue-600 hover:bg-blue-50">
                  <Edit className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="sm" className="text-red-600 border-red-600 hover:bg-red-50">
                  <Trash2 className="h-4 w-4" />
                </Button>
              </CardFooter>
            </Card>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
};

export default AccommodationResorts;