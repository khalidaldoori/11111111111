import React from 'react';
import { motion } from 'framer-motion';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardFooter, CardDescription } from "@/components/ui/card";
import { PlusCircle, Edit, Trash2, Search, Building, Bed, Bath, DollarSign, MapPin } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';

const sampleApartments = [
  { id: 1, name: "شقة فاخرة بوسط المدينة", location: "وسط باريس", bedrooms: 2, bathrooms: 2, pricePerNight: "800 ر.س", imageKey: "luxury_apartment_paris" },
  { id: 2, name: "استوديو بإطلالة بحرية", location: "مارينا دبي", bedrooms: 1, bathrooms: 1, pricePerNight: "650 ر.س", imageKey: "sea_view_studio_dubai" },
  { id: 3, name: "شقة عائلية واسعة", location: "بالقرب من ديزني لاند", bedrooms: 3, bathrooms: 2, pricePerNight: "1200 ر.س", imageKey: "family_apartment_disney" },
];

const AccommodationApartments = () => {
  const [searchTerm, setSearchTerm] = React.useState('');

  const filteredApartments = sampleApartments.filter(apt =>
    apt.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    apt.location.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <h1 className="text-3xl font-bold text-primary">إدارة الشقق الفندقية</h1>
        <Button className="bg-primary hover:bg-primary/90 text-primary-foreground btn-glow">
          <PlusCircle className="ml-2 h-5 w-5" />
          إضافة شقة جديدة
        </Button>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
        <Input 
          type="text"
          placeholder="ابحث عن شقة..."
          className="pl-10 w-full md:w-1/2 lg:w-1/3 bg-background/80 border-border focus:ring-primary"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      {filteredApartments.length === 0 && (
        <p className="text-center text-muted-foreground py-8">لا توجد شقق تطابق بحثك.</p>
      )}

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {filteredApartments.map((apt, index) => (
          <motion.div
            key={apt.id}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3, delay: index * 0.05 }}
          >
            <Card className="overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300 card-hover h-full flex flex-col">
              <div className="relative h-48 w-full">
                <img  
                  alt={`صورة لـ ${apt.name}`} 
                  className="w-full h-full object-cover"
                  src={`https://source.unsplash.com/random/400x300/?apartment,${apt.imageKey}`}
                />
                 <Badge variant="destructive" className="absolute top-2 left-2 bg-red-500/80 text-white">
                  {apt.pricePerNight} / ليلة
                </Badge>
              </div>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg text-primary flex items-center gap-2">
                   <Building className="h-5 w-5"/> {apt.name}
                </CardTitle>
                <CardDescription className="text-xs text-muted-foreground">
                    <MapPin className="inline h-3 w-3 mr-1"/>{apt.location}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-2 text-sm flex-grow">
                <div className="flex items-center text-muted-foreground">
                  <Bed className="h-4 w-4 ml-1 text-blue-500" />
                  {apt.bedrooms} غرف نوم
                </div>
                <div className="flex items-center text-muted-foreground">
                  <Bath className="h-4 w-4 ml-1 text-green-500" />
                  {apt.bathrooms} حمامات
                </div>
              </CardContent>
              <CardFooter className="flex justify-end gap-2 p-4 bg-secondary/30">
                <Button variant="outline" size="sm" className="text-blue-600 border-blue-600 hover:bg-blue-50">
                  <Edit className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="sm" className="text-red-600 border-red-600 hover:bg-red-50">
                  <Trash2 className="h-4 w-4" />
                </Button>
              </CardFooter>
            </Card>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
};

export default AccommodationApartments;