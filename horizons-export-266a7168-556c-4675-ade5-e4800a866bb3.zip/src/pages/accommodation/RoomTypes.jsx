import React from 'react';
import { motion } from 'framer-motion';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { PlusCircle, Edit, Trash2, Search, Bed, Users, Wifi, Tv, Coffee } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';

const sampleRoomTypes = [
  { id: 1, name: "غرفة قياسية مفردة", capacity: 1, amenities: ["واي فاي", "تلفزيون"], priceRange: "200-400 ر.س", imageKey: "standard_single_room" },
  { id: 2, name: "غرفة ديلوكس مزدوجة", capacity: 2, amenities: ["واي فاي", "تلفزيون", "ميني بار"], priceRange: "500-800 ر.س", imageKey: "deluxe_double_room" },
  { id: 3, name: "جناح عائلي", capacity: 4, amenities: ["واي فاي", "تلفزيون", "ميني بار", "منطقة جلوس"], priceRange: "900-1500 ر.س", imageKey: "family_suite_room" },
  { id: 4, name: "جناح رئاسي", capacity: 2, amenities: ["كل وسائل الراحة", "جاكوزي", "شرفة خاصة"], priceRange: "2500-5000 ر.س", imageKey: "presidential_suite_room" },
];

const AmenityIcon = ({ amenity }) => {
  if (amenity.includes("واي فاي")) return <Wifi className="h-4 w-4 text-blue-500" />;
  if (amenity.includes("تلفزيون")) return <Tv className="h-4 w-4 text-purple-500" />;
  if (amenity.includes("ميني بار")) return <Coffee className="h-4 w-4 text-orange-500" />;
  return null;
};

const AccommodationRoomTypes = () => {
  const [searchTerm, setSearchTerm] = React.useState('');

  const filteredRoomTypes = sampleRoomTypes.filter(roomType =>
    roomType.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <h1 className="text-3xl font-bold text-primary">إدارة أنواع الغرف</h1>
        <Button className="bg-primary hover:bg-primary/90 text-primary-foreground btn-glow">
          <PlusCircle className="ml-2 h-5 w-5" />
          إضافة نوع غرفة جديد
        </Button>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
        <Input 
          type="text"
          placeholder="ابحث عن نوع غرفة..."
          className="pl-10 w-full md:w-1/2 lg:w-1/3 bg-background/80 border-border focus:ring-primary"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      {filteredRoomTypes.length === 0 && (
        <p className="text-center text-muted-foreground py-8">لا توجد أنواع غرف تطابق بحثك.</p>
      )}

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {filteredRoomTypes.map((roomType, index) => (
          <motion.div
            key={roomType.id}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3, delay: index * 0.05 }}
          >
            <Card className="overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300 card-hover h-full flex flex-col">
              <div className="relative h-40 w-full">
                <img  
                  alt={`صورة لـ ${roomType.name}`} 
                  className="w-full h-full object-cover"
                  src={`https://source.unsplash.com/random/400x250/?hotel_room,${roomType.imageKey}`}
                />
                 <Badge variant="default" className="absolute bottom-2 right-2 bg-primary/80 backdrop-blur-sm text-primary-foreground">
                  {roomType.priceRange}
                </Badge>
              </div>
              <CardHeader className="pb-2">
                <CardTitle className="text-md text-primary flex items-center gap-2">
                  <Bed className="h-5 w-5" /> {roomType.name}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-sm flex-grow">
                <div className="flex items-center text-muted-foreground">
                  <Users className="h-4 w-4 ml-1 text-green-500" />
                  السعة: {roomType.capacity} أفراد
                </div>
                <div>
                  <p className="text-muted-foreground mb-1">أبرز وسائل الراحة:</p>
                  <div className="flex flex-wrap gap-2">
                    {roomType.amenities.map(amenity => (
                      <Badge key={amenity} variant="outline" className="flex items-center gap-1">
                        <AmenityIcon amenity={amenity} />
                        {amenity}
                      </Badge>
                    ))}
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex justify-end gap-2 p-4 bg-secondary/30">
                <Button variant="outline" size="sm" className="text-blue-600 border-blue-600 hover:bg-blue-50">
                  <Edit className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="sm" className="text-red-600 border-red-600 hover:bg-red-50">
                  <Trash2 className="h-4 w-4" />
                </Button>
              </CardFooter>
            </Card>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
};

export default AccommodationRoomTypes;