import React from 'react';
import { motion } from 'framer-motion';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { PlusCircle, Search, Filter, FileText, Globe, ListOrdered } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const sampleVisaRequirements = [
  { 
    country: "الولايات المتحدة الأمريكية", 
    visaType: "B1/B2 (سياحة/أعمال)", 
    requirements: ["جواز سفر ساري المفعول", "صورة شخصية حديثة", "نموذج DS-160", "إثبات القدرة المالية", "خطاب دعوة (إن وجد)"], 
    processingTime: "يختلف حسب السفارة/القنصلية", 
    fees: "185 دولار أمريكي (تقريباً)" 
  },
  { 
    country: "دول الشنغن (مثال: فرنسا)", 
    visaType: "شنغن سياحية", 
    requirements: ["جواز سفر ساري", "صور شخصية", "تأمين سفر", "حجز طيران وفندق", "كشف حساب بنكي"], 
    processingTime: "15-45 يوم", 
    fees: "80 يورو" 
  },
  { 
    country: "المملكة المتحدة", 
    visaType: "Standard Visitor Visa", 
    requirements: ["جواز سفر ساري", "إثباتات مالية", "تفاصيل الإقامة والرحلة", "خطاب عمل (إذا موظف)"], 
    processingTime: "3-6 أسابيع", 
    fees: "ابتداءً من 115 جنيه إسترليني" 
  },
];

const VisasRequirements = () => {
  const [searchTerm, setSearchTerm] = React.useState('');

  const filteredRequirements = sampleVisaRequirements.filter(req =>
    req.country.toLowerCase().includes(searchTerm.toLowerCase()) ||
    req.visaType.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <h1 className="text-3xl font-bold text-primary">متطلبات التأشيرات حسب الدول</h1>
        <div className="flex gap-2">
          <Button variant="outline" className="btn-glow">
            <Filter className="ml-2 h-4 w-4" />
            تصفية
          </Button>
          <Button className="bg-primary hover:bg-primary/90 text-primary-foreground btn-glow">
            <PlusCircle className="ml-2 h-5 w-5" />
            إضافة متطلبات دولة جديدة
          </Button>
        </div>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
        <Input 
          type="text"
          placeholder="ابحث عن دولة أو نوع تأشيرة..."
          className="pl-10 w-full md:w-1/2 lg:w-1/3 bg-background/80 border-border focus:ring-primary"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>
      
      {filteredRequirements.length === 0 && (
        <p className="text-center text-muted-foreground py-8">لا توجد متطلبات تطابق بحثك.</p>
      )}

      <Accordion type="single" collapsible className="w-full space-y-3">
        {filteredRequirements.map((req, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3, delay: index * 0.05 }}
          >
            <AccordionItem value={`item-${index}`} className="bg-card border border-border rounded-lg shadow-sm hover:shadow-md transition-shadow">
              <AccordionTrigger className="p-4 text-primary hover:no-underline">
                <div className="flex items-center gap-3">
                  <Globe className="h-5 w-5" />
                  <span className="font-semibold">{req.country} - {req.visaType}</span>
                </div>
              </AccordionTrigger>
              <AccordionContent className="p-4 pt-0 text-sm text-muted-foreground">
                <p className="mb-2"><span className="font-semibold text-foreground">الرسوم:</span> {req.fees}</p>
                <p className="mb-3"><span className="font-semibold text-foreground">وقت المعالجة التقديري:</span> {req.processingTime}</p>
                <h4 className="font-semibold text-foreground mb-1 flex items-center gap-1"><ListOrdered className="h-4 w-4"/> المتطلبات الأساسية:</h4>
                <ul className="list-disc list-inside space-y-1">
                  {req.requirements.map((item, idx) => <li key={idx}>{item}</li>)}
                </ul>
                <img  alt={`علم ${req.country}`} className="w-20 h-auto mt-3 rounded opacity-80" src={`https://source.unsplash.com/random/150x100/?flag,${req.country.toLowerCase().replace(/\s/g, '_')}`} />
              </AccordionContent>
            </AccordionItem>
          </motion.div>
        ))}
      </Accordion>
    </motion.div>
  );
};

export default VisasRequirements;