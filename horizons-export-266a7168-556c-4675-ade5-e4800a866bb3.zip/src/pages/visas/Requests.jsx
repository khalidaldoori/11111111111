import React from 'react';
import { motion } from 'framer-motion';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { PlusCircle, Search, Filter, Briefcase, User, Globe, CalendarCheck, CheckCircle, AlertCircle, XCircle, Eye } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

const sampleVisaRequests = [
  { id: "VR001", clientName: "أحمد الهاشمي", avatarSeed: "ahmed_visa", country: "الولايات المتحدة", submissionDate: "2025-05-10", status: "قيد المراجعة", expectedDate: "2025-07-01" },
  { id: "VR002", clientName: "فاطمة الزهراني", avatarSeed: "fatima_visa", country: "فرنسا (شنغن)", submissionDate: "2025-05-20", status: "موافق عليها", expectedDate: "2025-06-15" },
  { id: "VR003", clientName: "خالد الحربي", avatarSeed: "khalid_visa", country: "المملكة المتحدة", submissionDate: "2025-06-01", status: "مرفوضة", expectedDate: "N/A" },
];

const getStatusVisaIconAndVariant = (status) => {
  if (status === "موافق عليها") return { icon: <CheckCircle className="h-4 w-4 text-green-500" />, variant: "success" };
  if (status === "قيد المراجعة") return { icon: <AlertCircle className="h-4 w-4 text-yellow-500" />, variant: "warning" };
  if (status === "مرفوضة") return { icon: <XCircle className="h-4 w-4 text-red-500" />, variant: "destructive" };
  return { icon: <Briefcase className="h-4 w-4 text-gray-500" />, variant: "secondary" };
};


const VisasRequests = () => {
  const [searchTerm, setSearchTerm] = React.useState('');

  const filteredRequests = sampleVisaRequests.filter(req =>
    req.clientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    req.country.toLowerCase().includes(searchTerm.toLowerCase()) ||
    req.id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <h1 className="text-3xl font-bold text-primary">طلبات التأشيرات</h1>
        <div className="flex gap-2">
          <Button variant="outline" className="btn-glow">
            <Filter className="ml-2 h-4 w-4" />
            تصفية
          </Button>
          <Button className="bg-primary hover:bg-primary/90 text-primary-foreground btn-glow">
            <PlusCircle className="ml-2 h-5 w-5" />
            إضافة طلب تأشيرة جديد
          </Button>
        </div>
      </div>

      <Card className="shadow-lg">
        <CardHeader className="flex flex-col md:flex-row justify-between items-center gap-2">
           <div>
            <CardTitle className="text-xl text-primary">قائمة طلبات التأشيرات</CardTitle>
            <CardDescription>متابعة حالة جميع طلبات التأشيرات المقدمة.</CardDescription>
          </div>
          <div className="relative w-full md:w-auto">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
            <Input 
              type="text"
              placeholder="ابحث عن طلب تأشيرة..."
              className="pl-10 w-full md:w-64 bg-background/80 border-border focus:ring-primary"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </CardHeader>
        <CardContent>
          {filteredRequests.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">لا توجد طلبات تأشيرات تطابق بحثك.</p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>معرف الطلب</TableHead>
                    <TableHead>اسم العميل</TableHead>
                    <TableHead>الدولة</TableHead>
                    <TableHead>تاريخ التقديم</TableHead>
                    <TableHead>الحالة</TableHead>
                    <TableHead>التاريخ المتوقع للرد</TableHead>
                    <TableHead className="text-left">إجراءات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredRequests.map((req, index) => {
                    const statusInfo = getStatusVisaIconAndVariant(req.status);
                    return (
                      <motion.tr 
                        key={req.id}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ duration: 0.3, delay: index * 0.05 }}
                        className="hover:bg-muted/50 transition-colors"
                      >
                        <TableCell className="font-medium">{req.id}</TableCell>
                        <TableCell className="flex items-center gap-2">
                          <Avatar className="h-8 w-8">
                            <AvatarImage src={`https://source.unsplash.com/random/50x50/?person,${req.avatarSeed}`} alt={req.clientName} />
                            <AvatarFallback>{req.clientName.substring(0,1)}</AvatarFallback>
                          </Avatar>
                          {req.clientName}
                        </TableCell>
                        <TableCell className="flex items-center gap-1">
                          <Globe className="h-4 w-4 text-muted-foreground" /> {req.country}
                        </TableCell>
                        <TableCell>{req.submissionDate}</TableCell>
                        <TableCell>
                          <Badge variant={statusInfo.variant} className="flex items-center gap-1">
                            {statusInfo.icon} {req.status}
                          </Badge>
                        </TableCell>
                        <TableCell>{req.expectedDate}</TableCell>
                        <TableCell className="text-left">
                          <Button variant="ghost" size="icon" title="عرض التفاصيل" className="text-primary hover:text-primary/80">
                            <Eye className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </motion.tr>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default VisasRequests;