import React from 'react';
import { motion } from 'framer-motion';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { PlusCircle, Filter, Download, Eye } from 'lucide-react';
import { Input } from '@/components/ui/input';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";

const sampleBookings = [
  { id: "B001", customer: "أحمد خالد", trip: "رحلة الأحلام إلى باريس", date: "2025-07-15", status: "مؤكد", amount: "5000 ر.س" },
  { id: "B002", customer: "فاطمة علي", trip: "مغامرة جبال الألب", date: "2025-08-01", status: "قيد الانتظار", amount: "8000 ر.س" },
  { id: "B003", customer: "يوسف حسن", trip: "استرخاء في جزر المالديف", date: "2025-09-10", status: "ملغي", amount: "12000 ر.س" },
  { id: "B004", customer: "سارة إبراهيم", trip: "اكتشف كنوز روما", date: "2025-07-20", status: "مؤكد", amount: "6500 ر.س" },
  { id: "B005", customer: "محمد عبدالله", trip: "رحلة الأحلام إلى باريس", date: "2025-08-05", status: "مؤكد", amount: "5000 ر.س" },
];

const getStatusBadgeVariant = (status) => {
  switch (status) {
    case "مؤكد": return "success";
    case "قيد الانتظار": return "warning";
    case "ملغي": return "destructive";
    default: return "secondary";
  }
};

const Bookings = () => {
  const [searchTerm, setSearchTerm] = React.useState('');

  const filteredBookings = sampleBookings.filter(booking =>
    booking.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
    booking.customer.toLowerCase().includes(searchTerm.toLowerCase()) ||
    booking.trip.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <h1 className="text-3xl font-bold text-primary">إدارة الحجوزات</h1>
        <div className="flex gap-2">
          <Button variant="outline" className="btn-glow">
            <Filter className="ml-2 h-4 w-4" />
            تصفية
          </Button>
          <Button className="bg-primary hover:bg-primary/90 text-primary-foreground btn-glow">
            <PlusCircle className="ml-2 h-5 w-5" />
            إضافة حجز جديد
          </Button>
        </div>
      </div>

      <Card className="shadow-lg">
        <CardHeader className="flex flex-col md:flex-row justify-between items-center gap-2">
          <CardTitle className="text-xl text-primary">قائمة الحجوزات</CardTitle>
          <div className="flex gap-2 w-full md:w-auto">
            <Input 
              type="text"
              placeholder="ابحث (رقم الحجز, العميل, الرحلة)..."
              className="w-full md:w-64 bg-background/80 border-border focus:ring-primary"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <Button variant="outline" size="icon" className="btn-glow">
              <Download className="h-5 w-5" />
              <span className="sr-only">تصدير</span>
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {filteredBookings.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">لا توجد حجوزات تطابق بحثك.</p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>رقم الحجز</TableHead>
                    <TableHead>العميل</TableHead>
                    <TableHead>الرحلة</TableHead>
                    <TableHead>التاريخ</TableHead>
                    <TableHead>الحالة</TableHead>
                    <TableHead>المبلغ</TableHead>
                    <TableHead className="text-left">إجراءات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredBookings.map((booking, index) => (
                    <motion.tr 
                      key={booking.id}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ duration: 0.3, delay: index * 0.05 }}
                      className="hover:bg-muted/50 transition-colors"
                    >
                      <TableCell className="font-medium">{booking.id}</TableCell>
                      <TableCell>{booking.customer}</TableCell>
                      <TableCell>{booking.trip}</TableCell>
                      <TableCell>{booking.date}</TableCell>
                      <TableCell>
                        <Badge variant={getStatusBadgeVariant(booking.status)}>{booking.status}</Badge>
                      </TableCell>
                      <TableCell>{booking.amount}</TableCell>
                      <TableCell className="text-left">
                        <Button variant="ghost" size="icon" className="text-primary hover:text-primary/80">
                          <Eye className="h-5 w-5" />
                          <span className="sr-only">عرض التفاصيل</span>
                        </Button>
                      </TableCell>
                    </motion.tr>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default Bookings;