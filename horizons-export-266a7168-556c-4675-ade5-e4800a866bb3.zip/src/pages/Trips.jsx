import React from 'react';
import { motion } from 'framer-motion';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { PlusCircle, Edit, Trash2, Search } from 'lucide-react';
import { Input } from '@/components/ui/input';

const sampleTrips = [
  { id: 1, name: "رحلة الأحلام إلى باريس", destination: "باريس, فرنسا", duration: "7 أيام", price: "5000 ر.س", imageKey: "paris" },
  { id: 2, name: "مغامرة جبال الألب", destination: "سويسرا", duration: "10 أيام", price: "8000 ر.س", imageKey: "alps" },
  { id: 3, name: "استرخاء في جزر المالديف", destination: "المالديف", duration: "5 أيام", price: "12000 ر.س", imageKey: "maldives" },
  { id: 4, name: "اكتشف كنوز روما", destination: "روما, إيطاليا", duration: "6 أيام", price: "6500 ر.س", imageKey: "rome" },
];

const imagePlaceholders = {
  paris: "برج إيفل في باريس مع سماء الغروب",
  alps: "جبال الألب السويسرية المغطاة بالثلوج",
  maldives: "شاطئ استوائي في جزر المالديف مع مياه فيروزية",
  rome: "الكولوسيوم في روما تحت سماء زرقاء صافية"
};

const Trips = () => {
  const [searchTerm, setSearchTerm] = React.useState('');

  const filteredTrips = sampleTrips.filter(trip => 
    trip.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    trip.destination.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <h1 className="text-3xl font-bold text-primary">إدارة الرحلات</h1>
        <Button className="bg-primary hover:bg-primary/90 text-primary-foreground btn-glow">
          <PlusCircle className="ml-2 h-5 w-5" />
          إضافة رحلة جديدة
        </Button>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
        <Input 
          type="text"
          placeholder="ابحث عن رحلة (بالاسم أو الوجهة)..."
          className="pl-10 w-full md:w-1/2 lg:w-1/3 bg-background/80 border-border focus:ring-primary"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      {filteredTrips.length === 0 && (
        <p className="text-center text-muted-foreground py-8">لا توجد رحلات تطابق بحثك.</p>
      )}

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {filteredTrips.map((trip, index) => (
          <motion.div
            key={trip.id}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3, delay: index * 0.05 }}
          >
            <Card className="overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300 card-hover h-full flex flex-col">
              <div className="relative h-48 w-full">
                <img  
                  alt={trip.name} 
                  className="w-full h-full object-cover"
                 src="https://images.unsplash.com/photo-1610123701080-cc8bb93742ab" />
                <div className="absolute top-2 right-2 bg-primary text-primary-foreground px-2 py-1 text-xs font-semibold rounded">
                  {trip.duration}
                </div>
              </div>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg text-primary">{trip.name}</CardTitle>
                <CardDescription className="text-sm text-muted-foreground">{trip.destination}</CardDescription>
              </CardHeader>
              <CardContent className="flex-grow">
                <p className="text-xl font-semibold text-foreground">{trip.price}</p>
              </CardContent>
              <CardFooter className="flex justify-end gap-2 p-4 bg-secondary/30">
                <Button variant="outline" size="sm" className="text-blue-600 border-blue-600 hover:bg-blue-50">
                  <Edit className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="sm" className="text-red-600 border-red-600 hover:bg-red-50">
                  <Trash2 className="h-4 w-4" />
                </Button>
              </CardFooter>
            </Card>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
};

export default Trips;