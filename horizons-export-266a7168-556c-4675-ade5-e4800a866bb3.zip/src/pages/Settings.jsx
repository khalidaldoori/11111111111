import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { User, Bell, Shield, Palette, Globe } from 'lucide-react';
import { useToast } from "@/components/ui/use-toast";

const Settings = () => {
  const { toast } = useToast();

  const handleSaveChanges = (section) => {
    toast({
      title: "تم حفظ التغييرات بنجاح!",
      description: `تم تحديث إعدادات ${section}.`,
      className: "bg-green-500 text-white"
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-8 max-w-4xl mx-auto"
    >
      <h1 className="text-3xl font-bold text-primary">إعدادات النظام</h1>

      {/* Profile Settings */}
      <Card className="shadow-lg card-hover">
        <CardHeader>
          <div className="flex items-center gap-3">
            <User className="h-6 w-6 text-primary" />
            <CardTitle className="text-xl text-primary">إعدادات الملف الشخصي</CardTitle>
          </div>
          <CardDescription>قم بتحديث معلومات ملفك الشخصي وتفضيلات الحساب.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="fullName">الاسم الكامل</Label>
              <Input id="fullName" defaultValue="مدير النظام" className="bg-background/80 border-border focus:ring-primary" />
            </div>
            <div>
              <Label htmlFor="email">البريد الإلكتروني</Label>
              <Input id="email" type="email" defaultValue="admin@example.com" className="bg-background/80 border-border focus:ring-primary" />
            </div>
          </div>
          <div>
            <Label htmlFor="password">كلمة المرور الجديدة</Label>
            <Input id="password" type="password" placeholder="اتركها فارغة لعدم التغيير" className="bg-background/80 border-border focus:ring-primary" />
          </div>
          <Button onClick={() => handleSaveChanges("الملف الشخصي")} className="btn-glow">حفظ التغييرات</Button>
        </CardContent>
      </Card>

      <Separator />

      {/* Notification Settings */}
      <Card className="shadow-lg card-hover">
        <CardHeader>
          <div className="flex items-center gap-3">
            <Bell className="h-6 w-6 text-primary" />
            <CardTitle className="text-xl text-primary">إعدادات الإشعارات</CardTitle>
          </div>
          <CardDescription>تحكم في كيفية تلقي الإشعارات.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <Label htmlFor="emailNotifications">إشعارات البريد الإلكتروني</Label>
            <Switch id="emailNotifications" defaultChecked />
          </div>
          <div className="flex items-center justify-between">
            <Label htmlFor="pushNotifications">إشعارات المتصفح (Push)</Label>
            <Switch id="pushNotifications" />
          </div>
          <div className="flex items-center justify-between">
            <Label htmlFor="newBookingAlerts">تنبيهات الحجوزات الجديدة</Label>
            <Switch id="newBookingAlerts" defaultChecked />
          </div>
          <Button onClick={() => handleSaveChanges("الإشعارات")} className="btn-glow">حفظ التغييرات</Button>
        </CardContent>
      </Card>
      
      <Separator />

      {/* Appearance Settings */}
      <Card className="shadow-lg card-hover">
        <CardHeader>
          <div className="flex items-center gap-3">
            <Palette className="h-6 w-6 text-primary" />
            <CardTitle className="text-xl text-primary">إعدادات المظهر</CardTitle>
          </div>
          <CardDescription>خصص مظهر النظام.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <Label htmlFor="darkMode">الوضع الداكن</Label>
            <Switch id="darkMode" onCheckedChange={(checked) => {
              document.documentElement.classList.toggle('dark', checked);
            }} />
          </div>
           <div>
              <Label htmlFor="language">لغة الواجهة</Label>
              <select id="language" className="w-full mt-1 p-2 border rounded-md bg-background/80 border-border focus:ring-primary">
                <option value="ar">العربية</option>
                <option value="en">English</option>
              </select>
            </div>
          <Button onClick={() => handleSaveChanges("المظهر")} className="btn-glow">حفظ التغييرات</Button>
        </CardContent>
      </Card>

    </motion.div>
  );
};

export default Settings;