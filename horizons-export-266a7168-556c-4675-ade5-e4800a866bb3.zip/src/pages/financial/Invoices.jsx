import React from 'react';
import { motion } from 'framer-motion';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { PlusCircle, Search, Filter, FileText, Printer, DollarSign, CheckCircle, AlertTriangle, XCircle } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

const sampleInvoices = [
  { id: "INV001", clientName: "شركة الأفق للسفر", date: "2025-06-01", amount: "15,000 ر.س", status: "مدفوعة", dueDate: "2025-06-15" },
  { id: "INV002", clientName: "أحمد عبدالله", date: "2025-06-05", amount: "2,500 ر.س", status: "مستحقة", dueDate: "2025-06-20" },
  { id: "INV003", clientName: "مجموعة الفخامة للفنادق", date: "2025-05-20", amount: "35,000 ر.س", status: "متأخرة", dueDate: "2025-06-01" },
];

const getStatusInvoiceIconAndVariant = (status) => {
  if (status === "مدفوعة") return { icon: <CheckCircle className="h-4 w-4 text-green-500" />, variant: "success" };
  if (status === "مستحقة") return { icon: <AlertTriangle className="h-4 w-4 text-yellow-500" />, variant: "warning" };
  if (status === "متأخرة") return { icon: <XCircle className="h-4 w-4 text-red-500" />, variant: "destructive" };
  return { icon: <FileText className="h-4 w-4 text-gray-500" />, variant: "secondary" };
};

const FinancialInvoices = () => {
  const [searchTerm, setSearchTerm] = React.useState('');

  const filteredInvoices = sampleInvoices.filter(inv =>
    inv.clientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    inv.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
    inv.status.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <h1 className="text-3xl font-bold text-primary">الفواتير والمدفوعات</h1>
        <div className="flex gap-2">
          <Button variant="outline" className="btn-glow">
            <Filter className="ml-2 h-4 w-4" />
            تصفية
          </Button>
          <Button className="bg-primary hover:bg-primary/90 text-primary-foreground btn-glow">
            <PlusCircle className="ml-2 h-5 w-5" />
            إنشاء فاتورة جديدة
          </Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card className="bg-green-100 text-green-800 shadow">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">إجمالي المدفوعات (الشهر)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">45,000 ر.س</div>
          </CardContent>
        </Card>
         <Card className="bg-yellow-100 text-yellow-800 shadow">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">فواتير مستحقة</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">2,500 ر.س</div>
          </CardContent>
        </Card>
         <Card className="bg-red-100 text-red-800 shadow">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">فواتير متأخرة</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">35,000 ر.س</div>
          </CardContent>
        </Card>
      </div>

      <Card className="shadow-lg">
        <CardHeader className="flex flex-col md:flex-row justify-between items-center gap-2">
           <div>
            <CardTitle className="text-xl text-primary">قائمة الفواتير</CardTitle>
            <CardDescription>عرض وإدارة جميع الفواتير الصادرة والواردة.</CardDescription>
          </div>
          <div className="relative w-full md:w-auto">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
            <Input 
              type="text"
              placeholder="ابحث عن فاتورة..."
              className="pl-10 w-full md:w-64 bg-background/80 border-border focus:ring-primary"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </CardHeader>
        <CardContent>
          {filteredInvoices.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">لا توجد فواتير تطابق بحثك.</p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>رقم الفاتورة</TableHead>
                    <TableHead>العميل/المورد</TableHead>
                    <TableHead>تاريخ الإصدار</TableHead>
                    <TableHead>المبلغ</TableHead>
                    <TableHead>تاريخ الاستحقاق</TableHead>
                    <TableHead>الحالة</TableHead>
                    <TableHead className="text-left">إجراءات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredInvoices.map((inv, index) => {
                    const statusInfo = getStatusInvoiceIconAndVariant(inv.status);
                    return (
                    <motion.tr 
                      key={inv.id}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ duration: 0.3, delay: index * 0.05 }}
                      className="hover:bg-muted/50 transition-colors"
                    >
                      <TableCell className="font-medium">{inv.id}</TableCell>
                      <TableCell>{inv.clientName}</TableCell>
                      <TableCell>{inv.date}</TableCell>
                      <TableCell className="font-semibold text-foreground flex items-center gap-1">
                        <DollarSign className="h-4 w-4 text-green-600" />
                        {inv.amount}
                      </TableCell>
                      <TableCell>{inv.dueDate}</TableCell>
                      <TableCell>
                        <Badge variant={statusInfo.variant} className="flex items-center gap-1">
                           {statusInfo.icon} {inv.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-left">
                        <Button variant="ghost" size="icon" title="طباعة الفاتورة" className="text-primary hover:text-primary/80">
                          <Printer className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </motion.tr>
                  );
                })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default FinancialInvoices;