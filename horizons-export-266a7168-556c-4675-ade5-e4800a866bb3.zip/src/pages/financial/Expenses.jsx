import React from 'react';
import { motion } from 'framer-motion';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { PlusCircle, Search, Filter, Edit, Trash2, ShoppingCart, Building, Plane, DollarSign, FileText } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

const sampleExpenses = [
  { id: "EXP001", date: "2025-06-01", category: "إيجارات مكاتب", description: "إيجار مكتب الرياض - يونيو", amount: "5,000 ر.س", vendor: "شركة العقارات المتحدة" },
  { id: "EXP002", date: "2025-06-03", category: "تسويق وإعلان", description: "حملة إعلانية عبر جوجل", amount: "2,500 ر.س", vendor: "Google Ads" },
  { id: "EXP003", date: "2025-06-05", category: "فواتير خدمات", description: "فاتورة كهرباء مكتب جدة", amount: "800 ر.س", vendor: "شركة الكهرباء" },
  { id: "EXP004", date: "2025-06-07", category: "مستلزمات مكتبية", description: "أوراق وأحبار طابعات", amount: "350 ر.س", vendor: "مكتبة جرير" },
];

const getCategoryIcon = (category) => {
  if (category.includes("إيجار")) return <Building className="h-4 w-4 text-purple-500" />;
  if (category.includes("تسويق")) return <ShoppingCart className="h-4 w-4 text-blue-500" />;
  if (category.includes("سفر")) return <Plane className="h-4 w-4 text-green-500" />;
  return <DollarSign className="h-4 w-4 text-gray-500" />;
};

const FinancialExpenses = () => {
  const [searchTerm, setSearchTerm] = React.useState('');

  const filteredExpenses = sampleExpenses.filter(exp =>
    exp.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
    exp.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
    exp.vendor.toLowerCase().includes(searchTerm.toLowerCase()) ||
    exp.id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <h1 className="text-3xl font-bold text-primary">إدارة المصروفات</h1>
        <div className="flex gap-2">
          <Button variant="outline" className="btn-glow">
            <Filter className="ml-2 h-4 w-4" />
            تصفية
          </Button>
          <Button className="bg-primary hover:bg-primary/90 text-primary-foreground btn-glow">
            <PlusCircle className="ml-2 h-5 w-5" />
            إضافة مصروف جديد
          </Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card className="bg-red-100 text-red-800 shadow">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">إجمالي المصروفات (الشهر الحالي)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">8,650 ر.س</div>
          </CardContent>
        </Card>
         <Card className="bg-blue-100 text-blue-800 shadow">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">أكثر فئة مصروفات</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">إيجارات مكاتب</div>
          </CardContent>
        </Card>
      </div>

      <Card className="shadow-lg">
        <CardHeader className="flex flex-col md:flex-row justify-between items-center gap-2">
           <div>
            <CardTitle className="text-xl text-primary">قائمة المصروفات</CardTitle>
            <CardDescription>عرض وإدارة جميع المصروفات المسجلة.</CardDescription>
          </div>
          <div className="relative w-full md:w-auto">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
            <Input 
              type="text"
              placeholder="ابحث عن مصروف..."
              className="pl-10 w-full md:w-64 bg-background/80 border-border focus:ring-primary"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </CardHeader>
        <CardContent>
          {filteredExpenses.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">لا توجد مصروفات تطابق بحثك.</p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>المعرف</TableHead>
                    <TableHead>التاريخ</TableHead>
                    <TableHead>الفئة</TableHead>
                    <TableHead>الوصف</TableHead>
                    <TableHead>المبلغ</TableHead>
                    <TableHead>المورد/الجهة</TableHead>
                    <TableHead className="text-left">إجراءات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredExpenses.map((exp, index) => (
                    <motion.tr 
                      key={exp.id}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ duration: 0.3, delay: index * 0.05 }}
                      className="hover:bg-muted/50 transition-colors"
                    >
                      <TableCell className="font-medium">{exp.id}</TableCell>
                      <TableCell>{exp.date}</TableCell>
                      <TableCell className="flex items-center gap-1">
                        {getCategoryIcon(exp.category)}
                        <Badge variant="outline">{exp.category}</Badge>
                      </TableCell>
                      <TableCell>{exp.description}</TableCell>
                      <TableCell className="font-semibold text-red-600">{exp.amount}</TableCell>
                      <TableCell>{exp.vendor}</TableCell>
                      <TableCell className="text-left space-x-1 rtl:space-x-reverse">
                        <Button variant="ghost" size="icon" title="تعديل" className="text-blue-600 hover:text-blue-700">
                          <Edit className="h-4 w-4" />
                        </Button>
                         <Button variant="ghost" size="icon" title="حذف" className="text-red-600 hover:text-red-700">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </motion.tr>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default FinancialExpenses;