import React from 'react';
import { motion } from 'framer-motion';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardFooter, CardDescription } from "@/components/ui/card";
import { PlusCircle, Edit, Trash2, Search, ShieldCheck, Umbrella, DollarSign, FileText } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';

const sampleInsurancePlans = [
  { id: 1, name: "تأمين السفر الذهبي", provider: "التعاونية للتأمين", coverage: "تغطية طبية حتى 100,000 دولار، إلغاء الرحلة، فقدان الأمتعة.", price: "150 ر.س / للشخص", imageKey: "gold_travel_insurance" },
  { id: 2, name: "تأمين السفر الفضي", provider: "بوبا للتأمين", coverage: "تغطية طبية حتى 50,000 دولار، فقدان الأمتعة.", price: "90 ر.س / للشخص", imageKey: "silver_travel_insurance" },
  { id: 3, name: "تأمين إلغاء الرحلات", provider: "Allianz Travel", coverage: "تغطية تكاليف إلغاء الرحلة لأسباب محددة.", price: "5% من قيمة الرحلة", imageKey: "trip_cancellation_insurance" },
];

const ServicesInsurance = () => {
  const [searchTerm, setSearchTerm] = React.useState('');

  const filteredPlans = sampleInsurancePlans.filter(plan =>
    plan.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    plan.provider.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <h1 className="text-3xl font-bold text-primary">إدارة التأمين السياحي</h1>
        <Button className="bg-primary hover:bg-primary/90 text-primary-foreground btn-glow">
          <PlusCircle className="ml-2 h-5 w-5" />
          إضافة بوليصة تأمين جديدة
        </Button>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
        <Input 
          type="text"
          placeholder="ابحث عن بوليصة تأمين..."
          className="pl-10 w-full md:w-1/2 lg:w-1/3 bg-background/80 border-border focus:ring-primary"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      {filteredPlans.length === 0 && (
        <p className="text-center text-muted-foreground py-8">لا توجد بوالص تأمين تطابق بحثك.</p>
      )}

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {filteredPlans.map((plan, index) => (
          <motion.div
            key={plan.id}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3, delay: index * 0.05 }}
          >
            <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300 card-hover h-full flex flex-col">
              <div className="relative h-36 w-full bg-gradient-to-br from-blue-400 to-indigo-600 flex items-center justify-center">
                <Umbrella className="h-16 w-16 text-white opacity-80" />
                 <img  
                  alt={plan.name} 
                  className="absolute inset-0 w-full h-full object-cover opacity-20"
                  src={`https://source.unsplash.com/random/400x200/?insurance,${plan.imageKey}`}
                />
              </div>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg text-primary">{plan.name}</CardTitle>
                <CardDescription className="text-xs text-muted-foreground">المزود: {plan.provider}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-2 text-sm flex-grow">
                <div className="flex items-start text-muted-foreground">
                  <ShieldCheck className="h-4 w-4 ml-1 text-green-500 shrink-0 mt-0.5" />
                  <span>التغطية: {plan.coverage}</span>
                </div>
                <div className="flex items-center text-muted-foreground">
                  <DollarSign className="h-4 w-4 ml-1 text-red-500" />
                  السعر: <Badge variant="default">{plan.price}</Badge>
                </div>
              </CardContent>
              <CardFooter className="flex justify-between items-center p-4 bg-secondary/30">
                <Button variant="link" size="sm" className="p-0 h-auto text-primary">
                  <FileText className="h-3 w-3 ml-1" /> عرض التفاصيل
                </Button>
                <div className="flex gap-2">
                  <Button variant="outline" size="icon" className="text-blue-600 border-blue-600 hover:bg-blue-50 w-8 h-8">
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="icon" className="text-red-600 border-red-600 hover:bg-red-50 w-8 h-8">
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </CardFooter>
            </Card>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
};

export default ServicesInsurance;