import React from 'react';
import { motion } from 'framer-motion';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardFooter, CardDescription } from "@/components/ui/card";
import { PlusCircle, Edit, Trash2, Search, User, Languages, Map, Star, Phone } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';

const sampleGuides = [
  { id: 1, name: "أحمد المصري", languages: ["العربية", "الإنجليزية"], specialty: "آثار مصرية", rating: 4.8, phone: "010xxxxxxxx", imageKey: "egyptian_guide_ahmed" },
  { id: 2, name: "صوفي مارتين", languages: ["الفرنسية", "الإنجليزية", "الإسبانية"], specialty: "جولات باريس الفنية", rating: 4.9, phone: "+33xxxxxxxxx", imageKey: "paris_guide_sophie" },
  { id: 3, name: "كينتا سوزوكي", languages: ["اليابانية", "الإنجليزية"], specialty: "ثقافة طوكيو الحديثة", rating: 4.7, phone: "+81xxxxxxxxx", imageKey: "tokyo_guide_kenta" },
];

const GuideStarRating = ({ rating }) => (
  <div className="flex items-center">
    {[...Array(Math.floor(rating))].map((_, i) => <Star key={i} className="h-4 w-4 text-yellow-400 fill-current" />)}
    {rating % 1 !== 0 && <Star className="h-4 w-4 text-yellow-400 fill-current opacity-50" />} 
    {[...Array(5 - Math.ceil(rating))].map((_, i) => <Star key={`empty-${i}`} className="h-4 w-4 text-gray-300" />)}
    <span className="ml-1 text-xs text-muted-foreground">({rating})</span>
  </div>
);

const ServicesGuides = () => {
  const [searchTerm, setSearchTerm] = React.useState('');

  const filteredGuides = sampleGuides.filter(guide =>
    guide.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    guide.languages.join(" ").toLowerCase().includes(searchTerm.toLowerCase()) ||
    guide.specialty.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <h1 className="text-3xl font-bold text-primary">إدارة المرشدين السياحيين</h1>
        <Button className="bg-primary hover:bg-primary/90 text-primary-foreground btn-glow">
          <PlusCircle className="ml-2 h-5 w-5" />
          إضافة مرشد جديد
        </Button>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
        <Input 
          type="text"
          placeholder="ابحث عن مرشد سياحي..."
          className="pl-10 w-full md:w-1/2 lg:w-1/3 bg-background/80 border-border focus:ring-primary"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      {filteredGuides.length === 0 && (
        <p className="text-center text-muted-foreground py-8">لا يوجد مرشدون يطابقون بحثك.</p>
      )}

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {filteredGuides.map((guide, index) => (
          <motion.div
            key={guide.id}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3, delay: index * 0.05 }}
          >
            <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300 card-hover h-full flex flex-col">
              <CardHeader className="flex flex-row items-center space-x-4 rtl:space-x-reverse pb-3">
                <Avatar className="h-16 w-16 border-2 border-primary">
                  <AvatarImage src={`https://source.unsplash.com/random/100x100/?tour_guide,${guide.imageKey}`} alt={guide.name} />
                  <AvatarFallback className="text-xl bg-muted">{guide.name.substring(0, 1)}</AvatarFallback>
                </Avatar>
                <div>
                  <CardTitle className="text-lg text-primary">{guide.name}</CardTitle>
                  <GuideStarRating rating={guide.rating} />
                </div>
              </CardHeader>
              <CardContent className="space-y-2 text-sm flex-grow">
                <div className="flex items-center text-muted-foreground">
                  <Languages className="h-4 w-4 ml-1 text-blue-500" />
                  اللغات: {guide.languages.join(", ")}
                </div>
                <div className="flex items-center text-muted-foreground">
                  <Map className="h-4 w-4 ml-1 text-green-500" />
                  التخصص: {guide.specialty}
                </div>
                <div className="flex items-center text-muted-foreground">
                  <Phone className="h-4 w-4 ml-1 text-purple-500" />
                  الهاتف: {guide.phone}
                </div>
              </CardContent>
              <CardFooter className="flex justify-end gap-2 p-4 bg-secondary/30">
                <Button variant="outline" size="sm" className="text-blue-600 border-blue-600 hover:bg-blue-50">
                  <Edit className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="sm" className="text-red-600 border-red-600 hover:bg-red-50">
                  <Trash2 className="h-4 w-4" />
                </Button>
              </CardFooter>
            </Card>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
};

export default ServicesGuides;