import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart2, Users, Map, CalendarCheck2 } from 'lucide-react';

const stats = [
  { title: "إجمالي الرحلات", value: "125", icon: <Map className="h-8 w-8 text-blue-500" />, color: "bg-blue-100" },
  { title: "الحجوزات النشطة", value: "340", icon: <CalendarCheck2 className="h-8 w-8 text-green-500" />, color: "bg-green-100" },
  { title: "العملاء المسجلون", value: "1,280", icon: <Users className="h-8 w-8 text-purple-500" />, color: "bg-purple-100" },
  { title: "الإيرادات الشهرية", value: "25,000 ر.س", icon: <BarChart2 className="h-8 w-8 text-yellow-500" />, color: "bg-yellow-100" },
];

const Dashboard = () => {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <h1 className="text-3xl font-bold text-primary">لوحة التحكم الرئيسية</h1>
      
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat, index) => (
          <motion.div
            key={stat.title}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3, delay: index * 0.1 }}
          >
            <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300 card-hover glass-effect">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">{stat.title}</CardTitle>
                <div className={`p-2 rounded-full ${stat.color}`}>
                  {stat.icon}
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-foreground">{stat.value}</div>
                <p className="text-xs text-muted-foreground pt-1">
                  +10.5% عن الشهر الماضي
                </p>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card className="shadow-lg card-hover">
          <CardHeader>
            <CardTitle className="text-xl text-primary">الرحلات القادمة</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-3">
              {["رحلة إلى جزر المالديف", "مغامرة في صحراء الربع الخالي", "استكشاف مدينة البتراء"].map((trip, i) => (
                <li key={i} className="flex justify-between items-center p-3 bg-secondary rounded-md hover:bg-secondary/80 transition-colors">
                  <span className="text-foreground">{trip}</span>
                  <span className="text-sm text-muted-foreground">يبدأ في {i+5} يونيو</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
        <Card className="shadow-lg card-hover">
          <CardHeader>
            <CardTitle className="text-xl text-primary">أحدث الحجوزات</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-3">
              {["أحمد محمد - رحلة المالديف", "فاطمة علي - مغامرة الصحراء", "خالد عبدالله - مدينة البتراء"].map((booking, i) => (
                 <li key={i} className="flex justify-between items-center p-3 bg-secondary rounded-md hover:bg-secondary/80 transition-colors">
                  <span className="text-foreground">{booking}</span>
                  <span className="text-sm text-green-600 font-semibold">مؤكد</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </div>
      
      <div className="mt-8 text-center">
        <img  alt="خريطة العالم توضح وجهات سياحية شهيرة" className="w-full max-w-3xl mx-auto rounded-lg shadow-md" src="https://images.unsplash.com/photo-1524661135-423995f22d0b" />
      </div>

    </motion.div>
  );
};

export default Dashboard;