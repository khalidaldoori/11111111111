import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckSquare, ListTodo, Package, UserCheck, DollarSign, Filter, KanbanSquare } from 'lucide-react';

const initialWorkflowSteps = [
  { id: 'step1', name: 'استلام طلب جديد', icon: <Package className="h-6 w-6" />, status: 'مكتمل', details: 'تم استلام طلب باقة شهر عسل من العميل أحمد.', timestamp: '2025-07-01 10:05' },
  { id: 'step2', name: 'تعيين مسؤول للطلب', icon: <UserCheck className="h-6 w-6" />, status: 'مكتمل', details: 'تم تعيين الموظفة سارة لمتابعة الطلب.', timestamp: '2025-07-01 10:30' },
  { id: 'step3', name: 'تخطيط الباقة وإعداد العرض', icon: <ListTodo className="h-6 w-6" />, status: 'قيد التنفيذ', details: 'جاري تحديد الفنادق والرحلات والأنشطة.', timestamp: 'جاري...' },
  { id: 'step4', name: 'إرسال العرض للعميل', icon: <CheckSquare className="h-6 w-6" />, status: 'لم تبدأ بعد', details: '', timestamp: '' },
  { id: 'step5', name: 'تأكيد الحجز والدفع', icon: <DollarSign className="h-6 w-6" />, status: 'لم تبدأ بعد', details: '', timestamp: '' },
];

const getStatusColor = (status) => {
  if (status === 'مكتمل') return 'border-green-500 bg-green-50';
  if (status === 'قيد التنفيذ') return 'border-yellow-500 bg-yellow-50 animate-pulse';
  return 'border-gray-300 bg-gray-50';
};

const OperationsWorkflow = () => {
  const [workflowSteps, setWorkflowSteps] = useState(initialWorkflowSteps);
  const [selectedRequestId, setSelectedRequestId] = useState("RQ00123"); 

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <h1 className="text-3xl font-bold text-primary">متابعة سير العمل للطلبات</h1>
        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">طلب رقم:</span>
          <select 
            value={selectedRequestId} 
            onChange={(e) => setSelectedRequestId(e.target.value)}
            className="p-2 border rounded-md bg-background/80 border-border focus:ring-primary text-sm"
          >
            <option value="RQ00123">RQ00123 (باقة شهر العسل)</option>
            <option value="RQ00124">RQ00124 (رحلة عمل)</option>
          </select>
          <Button variant="outline" className="btn-glow">
            <Filter className="ml-2 h-4 w-4" />
            تصفية
          </Button>
        </div>
      </div>

      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="text-xl text-primary flex items-center gap-2">
            <KanbanSquare /> مراحل سير عمل الطلب: {selectedRequestId}
          </CardTitle>
        </CardHeader>
        <CardContent>
          {workflowSteps.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">لا توجد مراحل سير عمل محددة لهذا الطلب.</p>
          ) : (
            <div className="space-y-4 relative pr-8">
              <div className="absolute right-3 top-0 bottom-0 w-0.5 bg-gray-300"></div>
              {workflowSteps.map((step, index) => (
                <motion.div
                  key={step.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.3, delay: index * 0.1 }}
                  className={`relative pl-8 pr-4 py-3 border-r-4 rounded-md shadow-sm ${getStatusColor(step.status)}`}
                >
                  <div className={`absolute right-[-0.6rem] top-1/2 -translate-y-1/2 h-4 w-4 rounded-full ${step.status === 'مكتمل' ? 'bg-green-500' : step.status === 'قيد التنفيذ' ? 'bg-yellow-500' : 'bg-gray-300'} border-2 border-white`}></div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className={`${step.status === 'مكتمل' ? 'text-green-600' : step.status === 'قيد التنفيذ' ? 'text-yellow-600' : 'text-gray-600'}`}>{step.icon}</span>
                      <h3 className="font-semibold text-md text-foreground">{step.name}</h3>
                    </div>
                    <Badge variant={step.status === 'مكتمل' ? 'success' : step.status === 'قيد التنفيذ' ? 'warning' : 'secondary'}>
                      {step.status}
                    </Badge>
                  </div>
                  {step.details && <p className="text-xs text-muted-foreground mt-1">{step.details}</p>}
                  {step.timestamp && <p className="text-xs text-gray-400 mt-1">{step.timestamp}</p>}
                </motion.div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
      <div className="text-center mt-6">
         <img  alt="رسم توضيحي لسير عمل" className="mx-auto w-2/3 max-w-lg opacity-70 rounded-lg" src="https://images.unsplash.com/photo-1529400971042-dfa305370448" />
      </div>
    </motion.div>
  );
};

export default OperationsWorkflow;