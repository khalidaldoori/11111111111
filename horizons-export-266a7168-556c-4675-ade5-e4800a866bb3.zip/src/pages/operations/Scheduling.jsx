import React from 'react';
import { motion } from 'framer-motion';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { PlusCircle, CalendarDays, Clock, Users, Filter, Edit, Trash2 } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

const sampleSchedule = [
  { id: "SCH001", operation: "تجهيز باقة شهر العسل (عائلة الفلاني)", assignedTo: "فريق العمليات أ", dateTime: "2025-07-01 10:00", duration: "3 ساعات", status: "مجدولة" },
  { id: "SCH002", operation: "متابعة حجوزات طيران يوليو", assignedTo: "علي الأحمد", dateTime: "2025-07-02 14:00", duration: "يوم كامل", status: "قيد التنفيذ" },
  { id: "SCH003", operation: "تنسيق استقبال وفد شركة النجوم", assignedTo: "فريق الاستقبال", dateTime: "2025-08-10 09:00", duration: "4 ساعات", status: "مكتملة" },
];

const getStatusScheduleBadge = (status) => {
  if (status === "مكتملة") return "success";
  if (status === "قيد التنفيذ") return "warning";
  return "default";
};

const OperationsScheduling = () => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <h1 className="text-3xl font-bold text-primary">جدولة العمليات</h1>
        <div className="flex gap-2">
          <Button variant="outline" className="btn-glow">
            <Filter className="ml-2 h-4 w-4" />
            تصفية
          </Button>
          <Button className="bg-primary hover:bg-primary/90 text-primary-foreground btn-glow">
            <PlusCircle className="ml-2 h-5 w-5" />
            جدولة عملية جديدة
          </Button>
        </div>
      </div>

      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="text-xl text-primary">جدول العمليات الحالي</CardTitle>
          <CardDescription>نظرة عامة على العمليات المجدولة والقادمة.</CardDescription>
        </CardHeader>
        <CardContent>
          {sampleSchedule.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">لا توجد عمليات مجدولة حاليًا.</p>
          ) : (
            <div className="space-y-4">
              {sampleSchedule.map((item, index) => (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.3, delay: index * 0.1 }}
                >
                  <Card className="hover:shadow-md transition-shadow">
                    <CardHeader className="pb-3">
                      <div className="flex justify-between items-start">
                        <CardTitle className="text-md text-primary">{item.operation}</CardTitle>
                        <Badge variant={getStatusScheduleBadge(item.status)}>{item.status}</Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="grid grid-cols-2 md:grid-cols-4 gap-2 text-sm">
                      <div className="flex items-center text-muted-foreground">
                        <Users className="h-4 w-4 ml-1 text-indigo-500" />
                        المسؤول: {item.assignedTo}
                      </div>
                       <div className="flex items-center text-muted-foreground">
                        <CalendarDays className="h-4 w-4 ml-1 text-blue-500" />
                        التاريخ والوقت: {item.dateTime}
                      </div>
                      <div className="flex items-center text-muted-foreground">
                        <Clock className="h-4 w-4 ml-1 text-green-500" />
                        المدة: {item.duration}
                      </div>
                      <div className="flex justify-end items-center gap-1">
                        <Button variant="ghost" size="icon" className="h-7 w-7 text-blue-600 hover:bg-blue-100"><Edit className="h-4 w-4"/></Button>
                        <Button variant="ghost" size="icon" className="h-7 w-7 text-red-600 hover:bg-red-100"><Trash2 className="h-4 w-4"/></Button>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
      <div className="text-center mt-6">
        <img  alt="تقويم وجدول مهام" className="mx-auto w-1/2 max-w-md opacity-70 rounded-lg" src="https://images.unsplash.com/photo-1506784983877-45594efa4cbe" />
      </div>
    </motion.div>
  );
};

export default OperationsScheduling;