import React from 'react';
import { motion } from 'framer-motion';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { PlusCircle, User, Star, TrendingUp, Filter, Users } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';

const samplePerformance = [
  { id: 1, employeeName: "علي الأحمد", avatarSeed: "ali_perf", score: 4.5, salesTarget: "95%", customerSatisfaction: "92%", lastReview: "2025-05-01" },
  { id: 2, employeeName: "سارة عبدالله", avatarSeed: "sara_perf", score: 4.8, salesTarget: "105%", customerSatisfaction: "98%", lastReview: "2025-05-15" },
  { id: 3, employeeName: "محمد خالد", avatarSeed: "mohammed_perf", score: 4.2, salesTarget: "88%", customerSatisfaction: "90%", lastReview: "2025-04-20" },
];

const PerformanceStars = ({ score }) => {
  const fullStars = Math.floor(score);
  const halfStar = score % 1 >= 0.5;
  const emptyStars = 5 - fullStars - (halfStar ? 1 : 0);
  return (
    <div className="flex text-yellow-400">
      {[...Array(fullStars)].map((_, i) => <Star key={`full-${i}`} fill="currentColor" className="h-5 w-5" />)}
      {halfStar && <Star key="half" fill="currentColor" className="h-5 w-5 opacity-50" />}
      {[...Array(emptyStars)].map((_, i) => <Star key={`empty-${i}`} className="h-5 w-5 text-gray-300" />)}
    </div>
  );
};

const EmployeesPerformance = () => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <h1 className="text-3xl font-bold text-primary">تقييم أداء الموظفين</h1>
        <div className="flex gap-2">
          <Button variant="outline" className="btn-glow">
            <Filter className="ml-2 h-4 w-4" />
            تصفية
          </Button>
          <Button className="bg-primary hover:bg-primary/90 text-primary-foreground btn-glow">
            <PlusCircle className="ml-2 h-5 w-5" />
            إضافة تقييم جديد
          </Button>
        </div>
      </div>
      
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card className="bg-blue-500 text-white shadow-lg">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">متوسط التقييم العام</CardTitle>
            <Star className="h-4 w-4 text-yellow-300" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">4.5 / 5</div>
            <p className="text-xs text-blue-200">+0.2 عن الفترة السابقة</p>
          </CardContent>
        </Card>
         <Card className="bg-green-500 text-white shadow-lg">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">نسبة تحقيق الأهداف</CardTitle>
            <TrendingUp className="h-4 w-4 text-green-200" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">96%</div>
             <p className="text-xs text-green-200">متوسط تحقيق أهداف المبيعات</p>
          </CardContent>
        </Card>
         <Card className="bg-purple-500 text-white shadow-lg">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">الموظفين المتميزين</CardTitle>
            <Users className="h-4 w-4 text-purple-200" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">5</div>
            <p className="text-xs text-purple-200">حصلوا على تقييم أعلى من 4.7</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-1 lg:grid-cols-2 xl:grid-cols-3">
        {samplePerformance.map((perf, index) => (
          <motion.div
            key={perf.id}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3, delay: index * 0.1 }}
          >
            <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300 card-hover">
              <CardHeader className="flex items-center space-x-4 rtl:space-x-reverse">
                <Avatar className="h-12 w-12">
                  <AvatarImage src={`https://source.unsplash.com/random/100x100/?employee,${perf.avatarSeed}`} alt={perf.employeeName} />
                  <AvatarFallback>{perf.employeeName.substring(0,1)}</AvatarFallback>
                </Avatar>
                <div>
                  <CardTitle className="text-md text-primary">{perf.employeeName}</CardTitle>
                  <PerformanceStars score={perf.score} />
                </div>
              </CardHeader>
              <CardContent className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">تحقيق هدف المبيعات:</span>
                  <Badge variant={parseFloat(perf.salesTarget) >= 100 ? "success" : "warning"}>{perf.salesTarget}</Badge>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">رضا العملاء:</span>
                  <Badge variant="secondary">{perf.customerSatisfaction}</Badge>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">آخر مراجعة:</span>
                  <span className="font-medium">{perf.lastReview}</span>
                </div>
                <img  alt={`رسم بياني لأداء ${perf.employeeName}`} className="w-full h-20 object-contain mt-2 opacity-60" src={`https://source.unsplash.com/random/300x100/?graph,performance,${index}`} />
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
       {samplePerformance.length === 0 && (
        <p className="text-center text-muted-foreground py-8">لا توجد تقييمات أداء متاحة.</p>
      )}
    </motion.div>
  );
};

export default EmployeesPerformance;