import React from 'react';
import { motion } from 'framer-motion';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { PlusCircle, Award, Gift, Users, Filter, DollarSign } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

const sampleIncentives = [
  { id: 1, employeeName: "سارة عبدالله", avatarSeed: "sara_incentive", type: "مكافأة أداء", amount: "500 ر.س", date: "2025-06-01", reason: "تحقيق أهداف المبيعات بامتياز" },
  { id: 2, employeeName: "علي الأحمد", avatarSeed: "ali_incentive", type: "حافز فريق", amount: "رحلة مجانية", date: "2025-05-20", reason: "أفضل أداء فريق عمل" },
  { id: 3, employeeName: "محمد خالد", avatarSeed: "mohammed_incentive", type: "تقدير خاص", amount: "شهادة شكر", date: "2025-04-15", reason: "مبادرة متميزة في خدمة العملاء" },
];

const EmployeesIncentives = () => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <h1 className="text-3xl font-bold text-primary">الحوافز والمكافآت</h1>
        <div className="flex gap-2">
           <Button variant="outline" className="btn-glow">
            <Filter className="ml-2 h-4 w-4" />
            تصفية
          </Button>
          <Button className="bg-primary hover:bg-primary/90 text-primary-foreground btn-glow">
            <PlusCircle className="ml-2 h-5 w-5" />
            إضافة حافز/مكافأة
          </Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card className="bg-yellow-500 text-white shadow-lg">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">إجمالي المكافآت (الشهر الحالي)</CardTitle>
            <DollarSign className="h-4 w-4 text-yellow-200" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">1,200 ر.س</div>
            <p className="text-xs text-yellow-200">تم منح 3 مكافآت</p>
          </CardContent>
        </Card>
        <Card className="bg-teal-500 text-white shadow-lg">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">أنواع الحوافز المتاحة</CardTitle>
            <Gift className="h-4 w-4 text-teal-200" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">5 أنواع</div>
            <p className="text-xs text-teal-200">مالية, عينية, تقديرية, إلخ.</p>
          </CardContent>
        </Card>
        <Card className="bg-indigo-500 text-white shadow-lg">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">الموظفون الحاصلون على حوافز</CardTitle>
            <Users className="h-4 w-4 text-indigo-200" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">8 موظفين</div>
            <p className="text-xs text-indigo-200">خلال الربع الحالي</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-1 lg:grid-cols-2 xl:grid-cols-3">
        {sampleIncentives.map((incentive, index) => (
          <motion.div
            key={incentive.id}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3, delay: index * 0.05 }}
          >
            <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300 card-hover">
              <CardHeader className="flex items-start space-x-4 rtl:space-x-reverse pb-3">
                <Avatar className="h-12 w-12 border-2 border-yellow-400">
                  <AvatarImage src={`https://source.unsplash.com/random/100x100/?person,${incentive.avatarSeed}`} alt={incentive.employeeName} />
                  <AvatarFallback className="bg-yellow-100 text-yellow-600">{incentive.employeeName.substring(0,1)}</AvatarFallback>
                </Avatar>
                <div>
                  <CardTitle className="text-md text-primary">{incentive.employeeName}</CardTitle>
                  <Badge className="bg-yellow-400 text-yellow-900 hover:bg-yellow-400/90">{incentive.type}</Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-2 text-sm">
                <div className="flex items-center text-muted-foreground">
                  <Award className="h-4 w-4 ml-2 text-yellow-500" />
                  <span>القيمة/الوصف: <span className="font-semibold text-foreground">{incentive.amount}</span></span>
                </div>
                <div className="text-muted-foreground">
                  <p className="font-medium">السبب: <span className="font-normal">{incentive.reason}</span></p>
                </div>
                <p className="text-xs text-muted-foreground">التاريخ: {incentive.date}</p>
                <img  alt={`صورة رمزية للحافز المقدم لـ ${incentive.employeeName}`} className="w-full h-24 object-cover rounded-md mt-2 opacity-75" src={`https://source.unsplash.com/random/300x150/?gift,award,${index}`} />
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
       {sampleIncentives.length === 0 && (
        <p className="text-center text-muted-foreground py-8">لا توجد حوافز أو مكافآت مسجلة حاليًا.</p>
      )}
    </motion.div>
  );
};

export default EmployeesIncentives;