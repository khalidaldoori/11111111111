import React from 'react';
import { motion } from 'framer-motion';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { PlusCircle, Edit2, Trash2, ShieldCheck, Users, Settings2 } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

const sampleRoles = [
  { id: 1, name: "مدير النظام", permissions: ["كل الصلاحيات"], userCount: 1, color: "bg-red-500" },
  { id: 2, name: "مدير مبيعات", permissions: ["إدارة العروض", "إدارة العملاء", "عرض التقارير"], userCount: 3, color: "bg-blue-500" },
  { id: 3, name: "موظف خدمة عملاء", permissions: ["عرض الحجوزات", "التواصل مع العملاء"], userCount: 5, color: "bg-green-500" },
  { id: 4, name: "منسق عمليات", permissions: ["إدارة الرحلات", "جدولة المهام"], userCount: 2, color: "bg-yellow-500" },
];

const EmployeesRoles = () => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <h1 className="text-3xl font-bold text-primary">الأدوار والصلاحيات</h1>
        <Button className="bg-primary hover:bg-primary/90 text-primary-foreground btn-glow">
          <PlusCircle className="ml-2 h-5 w-5" />
          إضافة دور جديد
        </Button>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {sampleRoles.map((role, index) => (
          <motion.div
            key={role.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: index * 0.1 }}
          >
            <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300 card-hover h-full flex flex-col">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg text-primary flex items-center">
                    <ShieldCheck className={`h-6 w-6 ml-2 ${role.color.replace('bg-','text-')}`} /> 
                    {role.name}
                  </CardTitle>
                   <div className={`h-3 w-3 rounded-full ${role.color}`} />
                </div>
              </CardHeader>
              <CardContent className="space-y-2 text-sm flex-grow">
                <p className="font-semibold text-foreground">الصلاحيات الرئيسية:</p>
                <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                  {role.permissions.slice(0, 3).map(perm => <li key={perm}>{perm}</li>)}
                  {role.permissions.length > 3 && <li>والمزيد...</li>}
                </ul>
                <div className="flex items-center text-muted-foreground pt-2">
                  <Users className="h-4 w-4 ml-2 text-primary" />
                  <span>{role.userCount} مستخدمين بهذا الدور</span>
                </div>
                 <img  alt={`أيقونة تمثل دور ${role.name}`} className="w-20 h-20 object-contain mx-auto mt-3 opacity-70" src={`https://source.unsplash.com/random/150x150/?icon,security,${index}`} />
              </CardContent>
               <div className="p-4 bg-secondary/30 border-t flex justify-end gap-2">
                  <Button variant="outline" size="sm" className="text-blue-600 border-blue-600 hover:bg-blue-50">
                    <Edit2 className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="sm" className="text-red-600 border-red-600 hover:bg-red-50">
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
            </Card>
          </motion.div>
        ))}
      </div>
        {sampleRoles.length === 0 && (
        <p className="text-center text-muted-foreground py-8">لا توجد أدوار معرفة حاليًا.</p>
      )}
    </motion.div>
  );
};

export default EmployeesRoles;