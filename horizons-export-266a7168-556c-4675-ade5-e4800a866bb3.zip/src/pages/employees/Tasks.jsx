import React from 'react';
import { motion } from 'framer-motion';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { PlusCircle, Clock, User, CalendarDays, Filter, ListChecks } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

const sampleTasks = [
  { id: 1, taskName: "متابعة حجوزات يونيو", assignedTo: "علي الأحمد", avatarSeed: "ali_tasks", dueDate: "2025-06-15", status: "قيد التنفيذ", priority: "مرتفعة" },
  { id: 2, taskName: "إعداد تقرير المبيعات الشهري", assignedTo: "سارة عبدالله", avatarSeed: "sara_tasks", dueDate: "2025-06-10", status: "مكتملة", priority: "متوسطة" },
  { id: 3, taskName: "تحديث قائمة الفنادق المتعاقد معها", assignedTo: "محمد خالد", avatarSeed: "mohammed_tasks", dueDate: "2025-06-20", status: "لم تبدأ بعد", priority: "منخفضة" },
];

const getStatusBadgeVariant = (status) => {
  if (status === "مكتملة") return "success";
  if (status === "قيد التنفيذ") return "warning";
  return "secondary";
};

const getPriorityBadgeVariant = (priority) => {
  if (priority === "مرتفعة") return "destructive";
  if (priority === "متوسطة") return "default";
  return "outline";
};

const EmployeesTasks = () => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <h1 className="text-3xl font-bold text-primary">جدولة وإدارة المهام</h1>
         <div className="flex gap-2">
           <Button variant="outline" className="btn-glow">
            <Filter className="ml-2 h-4 w-4" />
            تصفية
          </Button>
          <Button className="bg-primary hover:bg-primary/90 text-primary-foreground btn-glow">
            <PlusCircle className="ml-2 h-5 w-5" />
            إضافة مهمة جديدة
          </Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card className="bg-blue-100 text-blue-800 shadow">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">إجمالي المهام</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">25</div>
          </CardContent>
        </Card>
        <Card className="bg-yellow-100 text-yellow-800 shadow">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">مهام قيد التنفيذ</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">10</div>
          </CardContent>
        </Card>
        <Card className="bg-green-100 text-green-800 shadow">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">مهام مكتملة (هذا الأسبوع)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">8</div>
          </CardContent>
        </Card>
      </div>


      <div className="grid gap-6 md:grid-cols-1 lg:grid-cols-2 xl:grid-cols-3">
        {sampleTasks.map((task, index) => (
          <motion.div
            key={task.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: index * 0.05 }}
          >
            <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300 card-hover">
              <CardHeader className="pb-3">
                <div className="flex justify-between items-start">
                  <CardTitle className="text-md text-primary">{task.taskName}</CardTitle>
                  <Badge variant={getPriorityBadgeVariant(task.priority)}>{task.priority}</Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <div className="flex items-center space-x-2 rtl:space-x-reverse">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={`https://source.unsplash.com/random/80x80/?avatar,${task.avatarSeed}`} alt={task.assignedTo} />
                    <AvatarFallback>{task.assignedTo.substring(0,1)}</AvatarFallback>
                  </Avatar>
                  <span className="text-muted-foreground">الموظف: <span className="font-medium text-foreground">{task.assignedTo}</span></span>
                </div>
                <div className="flex items-center text-muted-foreground">
                  <CalendarDays className="h-4 w-4 ml-2 text-primary" />
                  <span>تاريخ الاستحقاق: {task.dueDate}</span>
                </div>
                <div className="flex items-center">
                  <span className="text-muted-foreground ml-1">الحالة:</span>
                  <Badge variant={getStatusBadgeVariant(task.status)}>{task.status}</Badge>
                </div>
                 <img  alt={`أيقونة تمثل مهمة ${task.taskName}`} className="w-full h-20 object-contain mt-2 opacity-60 rounded-md" src={`https://source.unsplash.com/random/300x100/?checklist,task,${index}`} />
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
      {sampleTasks.length === 0 && (
        <p className="text-center text-muted-foreground py-8">لا توجد مهام مجدولة حاليًا.</p>
      )}
    </motion.div>
  );
};

export default EmployeesTasks;