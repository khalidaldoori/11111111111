import React from 'react';
import { motion } from 'framer-motion';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { PlusCircle, Search, Filter, MessageCircle as MessageCircleWarning, User, CalendarX2, AlertOctagon, Edit, Eye } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

const sampleComplaints = [
  { id: "CMP001", clientName: "خالد المحمد", avatarSeed: "khalid_comp", subject: "تأخير في تأكيد حجز الفندق", receivedDate: "2025-06-25", status: "قيد التحقيق", severity: "متوسطة", assignedTo: "فريق الدعم" },
  { id: "CMP002", clientName: "سارة الأحمدي", avatarSeed: "sara_comp", subject: "خدمة الغرف غير مرضية في فندق X", receivedDate: "2025-06-20", status: "تم الحل", severity: "منخفضة", assignedTo: "مدير الفندق" },
  { id: "CMP003", clientName: "شركة البناء الحديث", avatarSeed: "build_co_comp", subject: "خطأ في فاتورة رحلة جماعية", receivedDate: "2025-06-15", status: "تصعيد للإدارة", severity: "عالية", assignedTo: "القسم المالي" },
];

const getComplaintSeverityBadge = (severity) => {
  if (severity === "عالية") return "destructive";
  if (severity === "متوسطة") return "warning";
  return "default";
};

const getComplaintStatusBadge = (status) => {
  if (status.includes("الحل") || status.includes("الإغلاق")) return "success";
  if (status.includes("التحقيق") || status.includes("تصعيد")) return "destructive";
  return "secondary";
};

const CustomerCareComplaints = () => {
  const [searchTerm, setSearchTerm] = React.useState('');

  const filteredComplaints = sampleComplaints.filter(comp =>
    comp.clientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    comp.subject.toLowerCase().includes(searchTerm.toLowerCase()) ||
    comp.status.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <h1 className="text-3xl font-bold text-primary">إدارة شكاوى العملاء</h1>
        <div className="flex gap-2">
          <Button variant="outline" className="btn-glow">
            <Filter className="ml-2 h-4 w-4" />
            تصفية
          </Button>
          <Button className="bg-primary hover:bg-primary/90 text-primary-foreground btn-glow">
            <PlusCircle className="ml-2 h-5 w-5" />
            تسجيل شكوى جديدة
          </Button>
        </div>
      </div>
      
      <Card className="shadow-lg">
        <CardHeader className="flex flex-col md:flex-row justify-between items-center gap-2">
           <div>
            <CardTitle className="text-xl text-primary">قائمة الشكاوى</CardTitle>
            <CardDescription>متابعة ومعالجة جميع شكاوى العملاء لضمان رضاهم.</CardDescription>
          </div>
          <div className="relative w-full md:w-auto">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
            <Input 
              type="text"
              placeholder="ابحث عن شكوى..."
              className="pl-10 w-full md:w-64 bg-background/80 border-border focus:ring-primary"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </CardHeader>
        <CardContent>
          {filteredComplaints.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">لا توجد شكاوى تطابق بحثك.</p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>المعرف</TableHead>
                    <TableHead>العميل</TableHead>
                    <TableHead>الموضوع</TableHead>
                    <TableHead>تاريخ الاستلام</TableHead>
                    <TableHead>الحالة</TableHead>
                    <TableHead>الخطورة</TableHead>
                    <TableHead>الموظف المسؤول</TableHead>
                    <TableHead className="text-left">إجراءات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredComplaints.map((comp, index) => (
                    <motion.tr 
                      key={comp.id}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ duration: 0.3, delay: index * 0.05 }}
                      className="hover:bg-muted/50 transition-colors"
                    >
                      <TableCell className="font-medium">{comp.id}</TableCell>
                      <TableCell className="flex items-center gap-2">
                        <Avatar className="h-8 w-8">
                          <AvatarImage src={`https://source.unsplash.com/random/50x50/?person,${comp.avatarSeed}`} alt={comp.clientName} />
                          <AvatarFallback>{comp.clientName.substring(0,1)}</AvatarFallback>
                        </Avatar>
                        {comp.clientName}
                      </TableCell>
                      <TableCell>{comp.subject}</TableCell>
                      <TableCell>{comp.receivedDate}</TableCell>
                      <TableCell>
                        <Badge variant={getComplaintStatusBadge(comp.status)}>{comp.status}</Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant={getComplaintSeverityBadge(comp.severity)} className="flex items-center gap-1">
                          <AlertOctagon className="h-3 w-3"/> {comp.severity}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{comp.assignedTo}</Badge>
                      </TableCell>
                       <TableCell className="text-left space-x-1 rtl:space-x-reverse">
                        <Button variant="ghost" size="icon" title="عرض" className="text-primary hover:text-primary/80"><Eye className="h-4 w-4"/></Button>
                        <Button variant="ghost" size="icon" title="تعديل" className="text-blue-600 hover:text-blue-700"><Edit className="h-4 w-4"/></Button>
                      </TableCell>
                    </motion.tr>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default CustomerCareComplaints;