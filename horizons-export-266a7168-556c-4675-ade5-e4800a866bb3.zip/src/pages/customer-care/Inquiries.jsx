import React from 'react';
import { motion } from 'framer-motion';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { PlusCircle, Search, Filter, Mail, Phone, MessageSquare, User, Eye, Edit } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

const sampleInquiries = [
  { id: "INQ001", clientName: "نورة القحطاني", avatarSeed: "noura_inq", channel: "بريد إلكتروني", subject: "استفسار عن أسعار باقات المالديف", receivedDate: "2025-06-28", status: "جديد", assignedTo: "فريق المبيعات" },
  { id: "INQ002", clientName: "محمد الغامدي", avatarSeed: "mohammed_inq", channel: "مكالمة هاتفية", subject: "سؤال عن متطلبات تأشيرة لندن", receivedDate: "2025-06-27", status: "قيد المعالجة", assignedTo: "علي" },
  { id: "INQ003", clientName: "شركة الأمل للتجارة", avatarSeed: "amal_co_inq", channel: "نموذج الموقع", subject: "طلب عرض أسعار لرحلة فريق عمل", receivedDate: "2025-06-26", status: "تم الرد", assignedTo: "سارة" },
];

const getInquiryChannelIcon = (channel) => {
  if (channel.includes("بريد")) return <Mail className="h-4 w-4 text-blue-500" />;
  if (channel.includes("هاتف")) return <Phone className="h-4 w-4 text-green-500" />;
  return <MessageSquare className="h-4 w-4 text-purple-500" />;
};

const getInquiryStatusBadge = (status) => {
  if (status === "جديد") return "destructive";
  if (status === "قيد المعالجة") return "warning";
  if (status === "تم الرد") return "success";
  return "secondary";
};

const CustomerCareInquiries = () => {
  const [searchTerm, setSearchTerm] = React.useState('');

  const filteredInquiries = sampleInquiries.filter(inq =>
    inq.clientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    inq.subject.toLowerCase().includes(searchTerm.toLowerCase()) ||
    inq.status.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <h1 className="text-3xl font-bold text-primary">إدارة استفسارات العملاء</h1>
        <div className="flex gap-2">
          <Button variant="outline" className="btn-glow">
            <Filter className="ml-2 h-4 w-4" />
            تصفية
          </Button>
          <Button className="bg-primary hover:bg-primary/90 text-primary-foreground btn-glow">
            <PlusCircle className="ml-2 h-5 w-5" />
            تسجيل استفسار جديد
          </Button>
        </div>
      </div>
      
      <Card className="shadow-lg">
        <CardHeader className="flex flex-col md:flex-row justify-between items-center gap-2">
           <div>
            <CardTitle className="text-xl text-primary">قائمة الاستفسارات</CardTitle>
            <CardDescription>متابعة ومعالجة جميع استفسارات العملاء الواردة.</CardDescription>
          </div>
          <div className="relative w-full md:w-auto">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
            <Input 
              type="text"
              placeholder="ابحث عن استفسار..."
              className="pl-10 w-full md:w-64 bg-background/80 border-border focus:ring-primary"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </CardHeader>
        <CardContent>
          {filteredInquiries.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">لا توجد استفسارات تطابق بحثك.</p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>المعرف</TableHead>
                    <TableHead>العميل</TableHead>
                    <TableHead>القناة</TableHead>
                    <TableHead>الموضوع</TableHead>
                    <TableHead>تاريخ الاستلام</TableHead>
                    <TableHead>الحالة</TableHead>
                    <TableHead>الموظف المسؤول</TableHead>
                    <TableHead className="text-left">إجراءات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredInquiries.map((inq, index) => (
                    <motion.tr 
                      key={inq.id}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ duration: 0.3, delay: index * 0.05 }}
                      className="hover:bg-muted/50 transition-colors"
                    >
                      <TableCell className="font-medium">{inq.id}</TableCell>
                      <TableCell className="flex items-center gap-2">
                        <Avatar className="h-8 w-8">
                          <AvatarImage src={`https://source.unsplash.com/random/50x50/?customer,${inq.avatarSeed}`} alt={inq.clientName} />
                          <AvatarFallback>{inq.clientName.substring(0,1)}</AvatarFallback>
                        </Avatar>
                        {inq.clientName}
                      </TableCell>
                      <TableCell className="flex items-center gap-1">
                        {getInquiryChannelIcon(inq.channel)}
                        {inq.channel}
                      </TableCell>
                      <TableCell>{inq.subject}</TableCell>
                      <TableCell>{inq.receivedDate}</TableCell>
                      <TableCell>
                        <Badge variant={getInquiryStatusBadge(inq.status)}>{inq.status}</Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{inq.assignedTo}</Badge>
                      </TableCell>
                      <TableCell className="text-left space-x-1 rtl:space-x-reverse">
                        <Button variant="ghost" size="icon" title="عرض" className="text-primary hover:text-primary/80"><Eye className="h-4 w-4"/></Button>
                        <Button variant="ghost" size="icon" title="تعديل" className="text-blue-600 hover:text-blue-700"><Edit className="h-4 w-4"/></Button>
                      </TableCell>
                    </motion.tr>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default CustomerCareInquiries;